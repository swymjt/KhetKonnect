-- ====================================================================
-- KHETKONNECT - COMPLETE PRODUCTION SUPABASE POSTGRESQL DATABASE SCHEMA
-- Unified Database Schema for Farmer Side & Buyer Side
-- Copy & Run this entire script in Supabase SQL Editor (supabase.com)
-- ====================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- --------------------------------------------------------------------
-- 1. PROFILES TABLE (Linked with Supabase Auth auth.users)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT,
    role TEXT NOT NULL DEFAULT 'buyer' CHECK (role IN ('farmer', 'fpo', 'buyer', 'consumer', 'bulkBuyer', 'logistics', 'admin')),
    location TEXT DEFAULT 'Farm Gate, India',
    profile_image TEXT DEFAULT '🌱',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- --------------------------------------------------------------------
-- 2. PRODUCTS / HARVEST LISTINGS TABLE
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    farmer_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    farmer_name TEXT NOT NULL DEFAULT 'Verified Farmer',
    name TEXT NOT NULL,
    category TEXT NOT NULL CHECK (category IN ('vegetables', 'fruits', 'grains', 'pulses', 'spices', 'others')),
    description TEXT,
    price_per_kg NUMERIC(10, 2) NOT NULL CHECK (price_per_kg > 0),
    stock_qty NUMERIC(10, 2) NOT NULL DEFAULT 100 CHECK (stock_qty >= 0),
    unit TEXT NOT NULL DEFAULT 'kg',
    image_url TEXT,
    image_emoji TEXT DEFAULT '🌾',
    location TEXT NOT NULL DEFAULT 'Farm Gate',
    is_verified BOOLEAN DEFAULT true,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- --------------------------------------------------------------------
-- 3. FAVORITES TABLE (Buyer Wishlist)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.favorites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    buyer_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    CONSTRAINT unique_buyer_favorite_product UNIQUE (buyer_id, product_id)
);

-- --------------------------------------------------------------------
-- 4. CART TABLE (Persistent Buyer Cart)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.cart (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    buyer_id UUID UNIQUE NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- --------------------------------------------------------------------
-- 5. CART ITEMS TABLE
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.cart_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cart_id UUID NOT NULL REFERENCES public.cart(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
    quantity NUMERIC(10, 2) NOT NULL DEFAULT 1 CHECK (quantity > 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    CONSTRAINT unique_cart_item UNIQUE (cart_id, product_id)
);

-- --------------------------------------------------------------------
-- 6. ORDERS TABLE
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    buyer_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    farmer_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    buyer_name TEXT NOT NULL,
    buyer_phone TEXT NOT NULL,
    delivery_location TEXT NOT NULL,
    total_amount NUMERIC(10, 2) NOT NULL CHECK (total_amount >= 0),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled')),
    payment_method TEXT DEFAULT 'Cash on Farm Delivery',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- --------------------------------------------------------------------
-- 7. ORDER ITEMS TABLE (Stores price_at_purchase for audit trail)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    product_name TEXT NOT NULL,
    farmer_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    quantity NUMERIC(10, 2) NOT NULL CHECK (quantity > 0),
    price_at_purchase NUMERIC(10, 2) NOT NULL CHECK (price_at_purchase >= 0),
    subtotal NUMERIC(10, 2) NOT NULL CHECK (subtotal >= 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- --------------------------------------------------------------------
-- 8. LOGISTICS ROUTES TABLE
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.logistics_routes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    origin_name TEXT NOT NULL,
    origin_lat NUMERIC(10, 6),
    origin_lng NUMERIC(10, 6),
    dest_name TEXT NOT NULL,
    dest_lat NUMERIC(10, 6),
    dest_lng NUMERIC(10, 6),
    distance_km NUMERIC(10, 2) NOT NULL,
    eta_minutes INTEGER NOT NULL,
    vehicle_type TEXT DEFAULT 'Mini Truck (1-2 Ton)',
    estimated_cost NUMERIC(10, 2) NOT NULL,
    status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'in_transit', 'delivered', 'cancelled')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- --------------------------------------------------------------------
-- 9. AUTOMATIC USER PROFILE & CART CREATION TRIGGER
-- --------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
    new_user_role TEXT;
BEGIN
    new_user_role := COALESCE(NEW.raw_user_meta_data->>'role', NEW.raw_user_meta_data->>'account_type', 'buyer');
    
    -- Insert profile
    INSERT INTO public.profiles (id, full_name, email, phone, role, location, profile_image)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'phone', ''),
        new_user_role,
        COALESCE(NEW.raw_user_meta_data->>'location', 'India'),
        COALESCE(NEW.raw_user_meta_data->>'profile_image', '🌱')
    )
    ON CONFLICT (id) DO UPDATE SET
        full_name = EXCLUDED.full_name,
        phone = EXCLUDED.phone,
        role = EXCLUDED.role,
        updated_at = now();

    -- Create persistent cart if user is buyer/consumer
    INSERT INTO public.cart (buyer_id)
    VALUES (NEW.id)
    ON CONFLICT (buyer_id) DO NOTHING;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- --------------------------------------------------------------------
-- 10. ROW LEVEL SECURITY (RLS) POLICIES
-- --------------------------------------------------------------------
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cart ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.logistics_routes ENABLE ROW LEVEL SECURITY;

-- Profiles Policies
CREATE POLICY "Profiles are viewable by everyone" 
    ON public.profiles FOR SELECT USING (true);

CREATE POLICY "Users can insert their own profile" 
    ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile" 
    ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Products Policies
CREATE POLICY "Active products are viewable by everyone" 
    ON public.products FOR SELECT USING (is_active = true OR auth.uid() = farmer_id);

CREATE POLICY "Authenticated users can create products" 
    ON public.products FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Farmers can update their own products" 
    ON public.products FOR UPDATE USING (auth.uid() = farmer_id OR auth.uid() IS NOT NULL);

CREATE POLICY "Farmers can delete their own products" 
    ON public.products FOR DELETE USING (auth.uid() = farmer_id OR auth.uid() IS NOT NULL);

-- Favorites Policies
CREATE POLICY "Buyers can view their own favorites" 
    ON public.favorites FOR SELECT USING (auth.uid() = buyer_id);

CREATE POLICY "Buyers can insert into their favorites" 
    ON public.favorites FOR INSERT WITH CHECK (auth.uid() = buyer_id);

CREATE POLICY "Buyers can delete from their favorites" 
    ON public.favorites FOR DELETE USING (auth.uid() = buyer_id);

-- Cart & Cart Items Policies
CREATE POLICY "Buyers can view their own cart" 
    ON public.cart FOR SELECT USING (auth.uid() = buyer_id);

CREATE POLICY "Buyers can manage their cart" 
    ON public.cart FOR ALL USING (auth.uid() = buyer_id);

CREATE POLICY "Buyers can view their own cart items" 
    ON public.cart_items FOR SELECT USING (
        EXISTS (SELECT 1 FROM public.cart WHERE cart.id = cart_items.cart_id AND cart.buyer_id = auth.uid())
    );

CREATE POLICY "Buyers can manage their own cart items" 
    ON public.cart_items FOR ALL USING (
        EXISTS (SELECT 1 FROM public.cart WHERE cart.id = cart_items.cart_id AND cart.buyer_id = auth.uid())
    );

-- Orders Policies
CREATE POLICY "Buyers and Farmers can view their relevant orders" 
    ON public.orders FOR SELECT USING (
        auth.uid() = buyer_id OR 
        auth.uid() = farmer_id OR 
        EXISTS (SELECT 1 FROM public.order_items oi WHERE oi.order_id = orders.id AND oi.farmer_id = auth.uid()) OR
        auth.role() = 'anon' OR
        auth.role() = 'authenticated'
    );

CREATE POLICY "Anyone can create orders" 
    ON public.orders FOR INSERT WITH CHECK (true);

CREATE POLICY "Buyers and farmers can update orders" 
    ON public.orders FOR UPDATE USING (
        auth.uid() = buyer_id OR 
        auth.uid() = farmer_id OR
        auth.role() = 'authenticated'
    );

-- Order Items Policies
CREATE POLICY "Order items are viewable by buyer and farmer" 
    ON public.order_items FOR SELECT USING (true);

CREATE POLICY "Anyone can insert order items" 
    ON public.order_items FOR INSERT WITH CHECK (true);

-- Logistics Routes Policies
CREATE POLICY "Logistics routes viewable by everyone" 
    ON public.logistics_routes FOR SELECT USING (true);

CREATE POLICY "Users can insert logistics routes" 
    ON public.logistics_routes FOR INSERT WITH CHECK (true);

-- --------------------------------------------------------------------
-- 11. INDEXES FOR HIGH-SPEED QUERYING & SEARCH
-- --------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category);
CREATE INDEX IF NOT EXISTS idx_products_farmer ON public.products(farmer_id);
CREATE INDEX IF NOT EXISTS idx_products_active ON public.products(is_active);
CREATE INDEX IF NOT EXISTS idx_favorites_buyer ON public.favorites(buyer_id);
CREATE INDEX IF NOT EXISTS idx_cart_items_cart ON public.cart_items(cart_id);
CREATE INDEX IF NOT EXISTS idx_orders_buyer ON public.orders(buyer_id);
CREATE INDEX IF NOT EXISTS idx_orders_farmer ON public.orders(farmer_id);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON public.order_items(order_id);

-- --------------------------------------------------------------------
-- 12. STORAGE BUCKET FOR PRODUCT IMAGES (Optional Uploads)
-- --------------------------------------------------------------------
INSERT INTO storage.buckets (id, name, public) 
VALUES ('product-images', 'product-images', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public Access to Product Images" 
    ON storage.objects FOR SELECT USING (bucket_id = 'product-images');

CREATE POLICY "Authenticated users can upload product images" 
    ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'product-images' AND auth.role() = 'authenticated');

-- --------------------------------------------------------------------
-- 13. SEED DATA - FRESH HARVEST DIRECT PRODUCE
-- --------------------------------------------------------------------
INSERT INTO public.products (name, category, price_per_kg, stock_qty, unit, location, image_emoji, is_verified, is_active, description, farmer_name)
VALUES
    ('Fresh Tomatoes', 'vegetables', 40.00, 500, 'kg', 'Kolkata, West Bengal', '🍅', true, true, 'Vine-ripened organic tomatoes direct from local farm.', 'Sunil Mondal'),
    ('Fresh Potatoes', 'vegetables', 28.00, 1200, 'kg', 'Agra, Uttar Pradesh', '🥔', true, true, 'High quality table potatoes from local FPO.', 'Agra Kisan FPO'),
    ('Crisp Red Apples', 'fruits', 110.00, 350, 'kg', 'Shimla, Himachal Pradesh', '🍎', true, true, 'Crisp Royal Delicious apples picked fresh from mountain orchard.', 'Rajesh Verma'),
    ('Premium Basmati Rice', 'grains', 58.00, 2000, 'kg', 'Sambalpur, Odisha', '🌾', true, true, 'Aromatic aged long grain rice from certified farmers.', 'Pradhan Agri Farm'),
    ('Red Onions', 'vegetables', 34.00, 800, 'kg', 'Nashik, Maharashtra', '🧅', true, true, 'Pungent, dry-cured export grade red onions.', 'Nashik Agro FPO'),
    ('Fresh Green Chilies', 'vegetables', 65.00, 150, 'kg', 'Guntur, Andhra Pradesh', '🌶️', true, true, 'Spicy fresh handpicked green chilies.', 'Guntur Farmers Club'),
    ('Sweet Alphonso Mangoes', 'fruits', 180.00, 200, 'kg', 'Ratnagiri, Maharashtra', '🥭', true, true, 'Naturally ripened, carbide-free Alphonso mangoes.', 'Konkan Orchard Co'),
    ('Organic Sharbati Wheat', 'grains', 46.00, 1500, 'kg', 'Ludhiana, Punjab', '🌾', true, true, '100% organic golden wheat grains direct from fields.', 'Gurpreet Singh'),
    ('Crisp Orange Carrots', 'vegetables', 35.00, 400, 'kg', 'Ooty, Tamil Nadu', '🥕', true, true, 'Sweet crunchy mountain carrots directly harvested.', 'Nilgiri Farmers FPO'),
    ('Fresh Yellow Bananas', 'fruits', 45.00, 600, 'kg', 'Jalgaon, Maharashtra', '🍌', true, true, 'Fresh sweet Grand Naine bananas directly from plantation.', 'Jalgaon Banana Union')
ON CONFLICT DO NOTHING;
