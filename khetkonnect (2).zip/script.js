/**
 * ====================================================================
 * KHETKONNECT - MAIN JAVASCRIPT CONTROLLER
 * Farm-to-Buyer Ecosystem with Supabase Real-Time Backend,
 * Buyer Marketplace (Search, Filters, Favorites, Cart, Checkout, Orders),
 * Farmer CRM Dashboard, Leaflet Route Optimization & Multilingual Voice AI
 * ====================================================================
 */

document.addEventListener("DOMContentLoaded", function () {
    "use strict";

    /* ====================================================================
       1. SUPABASE CLIENT & DATA PERSISTENCE LAYER
       ==================================================================== */
    const SUPABASE_CONFIG = {
        url: (window.env && window.env.VITE_SUPABASE_URL) || "https://placeholder-project.supabase.co",
        anonKey: (window.env && window.env.VITE_SUPABASE_ANON_KEY) || "placeholder-anon-key"
    };

    let supabaseClient = null;
    let isSupabaseConfigured = false;

    if (window.supabase && SUPABASE_CONFIG.url && !SUPABASE_CONFIG.url.includes("placeholder-project")) {
        try {
            supabaseClient = window.supabase.createClient(SUPABASE_CONFIG.url, SUPABASE_CONFIG.anonKey);
            isSupabaseConfigured = true;
            console.log("🌾 KhetKonnect: Connected to Live Supabase Backend");
        } catch (e) {
            console.warn("🌾 KhetKonnect: Supabase init fallback", e);
        }
    }

    // Resilient local database engine ensuring 100% persistence & zero downtime
    const LocalDB = {
        get(key, defaultValue) {
            try {
                const data = localStorage.getItem(`khetkonnect_${key}`);
                return data ? JSON.parse(data) : defaultValue;
            } catch (e) {
                return defaultValue;
            }
        },
        set(key, value) {
            try {
                localStorage.setItem(`khetkonnect_${key}`, JSON.stringify(value));
            } catch (e) {
                console.error("LocalDB save error:", e);
            }
        }
    };

    // Initial Seeds if fresh instance
    const DEFAULT_PRODUCTS = [
        {
            id: "prod-1",
            farmer_name: "Ramesh Patil",
            name: "Fresh Tomatoes",
            category: "vegetables",
            price_per_kg: 42,
            stock_qty: 500,
            unit: "kg",
            location: "Nashik, Maharashtra",
            image_emoji: "🍅",
            is_verified: true,
            description: "Naturally vine-ripened, 100% organic direct from Nashik farm cluster."
        },
        {
            id: "prod-2",
            farmer_name: "Kisan Vikas FPO",
            name: "Fresh Potatoes",
            category: "vegetables",
            price_per_kg: 28,
            stock_qty: 1200,
            unit: "kg",
            location: "Agra, Uttar Pradesh",
            image_emoji: "🥔",
            is_verified: true,
            description: "High quality sorted table potatoes direct from FPO cold storage."
        },
        {
            id: "prod-3",
            farmer_name: "Himachal Orchard Cooperative",
            name: "Fresh Apples",
            category: "fruits",
            price_per_kg: 110,
            stock_qty: 350,
            unit: "kg",
            location: "Shimla, Himachal Pradesh",
            image_emoji: "🍎",
            is_verified: true,
            description: "Crisp Royal Delicious mountain apples picked fresh from high altitude orchards."
        },
        {
            id: "prod-4",
            farmer_name: "Mahanadi Farmers Collective",
            name: "Premium Rice",
            category: "grains",
            price_per_kg: 58,
            stock_qty: 2000,
            unit: "kg",
            location: "Sambalpur, Odisha",
            image_emoji: "🌾",
            is_verified: true,
            description: "Aromatic aged long grain rice harvested by certified farmer group."
        },
        {
            id: "prod-5",
            farmer_name: "Lasalgaon Mandi Farmer",
            name: "Red Onions",
            category: "vegetables",
            price_per_kg: 34,
            stock_qty: 850,
            unit: "kg",
            location: "Lasalgaon, Maharashtra",
            image_emoji: "🧅",
            is_verified: true,
            description: "Export-quality pungent red onions with long shelf life."
        },
        {
            id: "prod-6",
            farmer_name: "Ratnagiri Mango Growers",
            name: "Alphonso Mangoes",
            category: "fruits",
            price_per_kg: 180,
            stock_qty: 220,
            unit: "kg",
            location: "Ratnagiri, Maharashtra",
            image_emoji: "🥭",
            is_verified: true,
            description: "Naturally tree-ripened, 100% carbide-free authentic Alphonso mangoes."
        },
        {
            id: "prod-7",
            farmer_name: "Punjab Agro Green",
            name: "Organic Wheat (Kanak)",
            category: "grains",
            price_per_kg: 45,
            stock_qty: 1500,
            unit: "kg",
            location: "Ludhiana, Punjab",
            image_emoji: "🌾",
            is_verified: true,
            description: "Sharbati golden wheat grains grown without chemical pesticides."
        },
        {
            id: "prod-8",
            farmer_name: "Mahabaleshwar Berry Farm",
            name: "Fresh Strawberries",
            category: "fruits",
            price_per_kg: 160,
            stock_qty: 180,
            unit: "kg",
            location: "Mahabaleshwar, Maharashtra",
            image_emoji: "🍓",
            is_verified: true,
            description: "Juicy, hand-picked sweet winter strawberries."
        }
    ];

    if (!LocalDB.get("products") || LocalDB.get("products").length === 0) {
        LocalDB.set("products", DEFAULT_PRODUCTS);
    }

    if (!LocalDB.get("orders")) {
        LocalDB.set("orders", [
            {
                id: "ORD-9421",
                buyer_name: "Ananya Sharma",
                buyer_phone: "+91 9876543210",
                delivery_address: "Flat 402, Green Meadows, Mumbai",
                total_amount: 376,
                items: [
                    { name: "Fresh Tomatoes", quantity: 4, unit_price: 42, total: 168 },
                    { name: "Fresh Potatoes", quantity: 6, unit_price: 28, total: 168 }
                ],
                status: "packed",
                created_at: new Date(Date.now() - 3600000 * 4).toISOString()
            },
            {
                id: "ORD-8930",
                buyer_name: "Vikram Mehta (Retail Hub)",
                buyer_phone: "+91 9822334455",
                delivery_address: "Shop 12, APMC Market Yard, Pune",
                total_amount: 1160,
                items: [
                    { name: "Premium Rice", quantity: 20, unit_price: 58, total: 1160 }
                ],
                status: "in_transit",
                created_at: new Date(Date.now() - 3600000 * 20).toISOString()
            }
        ]);
    }

    if (!LocalDB.get("favorites")) {
        LocalDB.set("favorites", ["prod-1", "prod-3"]);
    }

    /* ====================================================================
       2. MULTILINGUAL TRANSLATION SYSTEM
       ==================================================================== */
    const TRANSLATIONS = {
        en: {
            nav_home: "Home",
            nav_marketplace: "Marketplace",
            nav_solutions: "Solutions",
            nav_ai: "AI Insights",
            nav_logistics: "Logistics",
            btn_voice: "Voice",
            btn_login: "Login",
            btn_signup: "Sign Up",
            btn_logout: "Logout",
            btn_favorites: "Favorites",
            menu_farmer_dashboard: "Farmer Dashboard",
            menu_my_orders: "My Orders",
            menu_favorites: "My Favorites",
            menu_profile: "My Profile",
            hero_tag: "🌱 DIGITAL AGRICULTURE MARKETPLACE",
            hero_title: "From <span>Farm</span><br>Directly to Your Table.",
            hero_description: "KhetKonnect connects farmers and FPOs directly with consumers and bulk buyers, reducing unnecessary intermediaries and ensuring fair prices for everyone.",
            hero_btn_explore: "Explore Marketplace",
            hero_btn_farmer: "👨‍🌾 Register as Farmer",
            stat_farmers: "Farmers Connected",
            stat_earnings: "Better Earnings",
            stat_prices: "Lower Prices",
            hero_price_tag: "FARMER DIRECT PRICE",
            hero_income_tag: "Better farmer income",
            hero_smart_delivery: "Smart Delivery",
            hero_route_sub: "AI Optimized Route",
            problem_tag: "THE PROBLEM",
            problem_title: "Too Many Middlemen.<br>Too Little Farmer Income.",
            problem_description: "Traditional agricultural supply chains involve multiple intermediaries. Farmers earn less while consumers pay more.",
            problem_1_title: "Low Farmer Earnings",
            problem_1_desc: "Farmers often receive only a small percentage of the final consumer price.",
            problem_2_title: "High Consumer Prices",
            problem_2_desc: "Multiple intermediaries increase the final price of agricultural products.",
            problem_3_title: "Inefficient Supply Chain",
            problem_3_desc: "Poor logistics and demand planning lead to transportation costs and food wastage.",
            solution_tag: "OUR SOLUTION",
            solution_title: "Connecting Farmers Directly With Buyers.",
            solution_desc: "KhetKonnect provides a transparent digital platform where farmers can directly sell their produce to consumers, retailers and bulk buyers.",
            solution_1_title: "Direct Marketplace",
            solution_1_desc: "Farmers and FPOs sell directly without unnecessary intermediaries.",
            solution_2_title: "AI Demand Forecasting",
            solution_2_desc: "AI predicts demand and market trends to help farmers make better decisions.",
            solution_3_title: "Smart Logistics",
            solution_3_desc: "Route optimization reduces delivery cost, time and food wastage.",
            label_farmer: "Farmer",
            label_consumer: "Consumer",
            market_tag: "DIRECT FROM FARMS",
            market_title: "Fresh Produce Marketplace",
            market_desc: "Buy fresh agricultural products directly from verified farmers.",
            cat_all: "All",
            cat_veg: "Vegetables",
            cat_fruits: "Fruits",
            cat_grains: "Grains",
            cat_others: "Others",
            btn_add_crop: "Farmer: List New Crop",
            btn_add_cart: "Add to Cart",
            badge_verified: "✓ Verified Farmer",
            badge_fpo: "✓ FPO Verified",
            ai_tag: "AI & DATA INTELLIGENCE",
            ai_title: "Smarter Decisions Powered by AI.",
            ai_desc: "AI analyzes market demand, seasonal trends and historical sales data to help farmers plan production and reduce wastage.",
            ai_pt_1: "✓ Demand Forecasting",
            ai_pt_2: "✓ Price Trend Analysis",
            ai_pt_3: "✓ Crop Recommendation",
            ai_pt_4: "✓ Market Insights",
            ai_select_crop: "Select Crop to Predict Demand:",
            ai_header_sub: "AI MARKET ANALYTICS",
            ai_header_title: "Demand Forecast",
            ai_forecast_label: "Predicted Demand Spike",
            ai_advice_tag: "💡 AI Recommendation:",
            ai_advice_default: "Optimal harvest time: Next 48 hours. High wholesale demand expected in nearby urban clusters.",
            logistics_tag: "SMART LOGISTICS & ROUTE OPTIMIZATION",
            logistics_title: "Smarter Routes.<br>Faster Delivery.",
            logistics_desc: "KhetKonnect connects farmers with logistics partners and uses route optimization to reduce transportation cost, transit time and food wastage.",
            btn_explore_logistics: "Explore Logistics & Routes →",
            logistics_status_tag: "🚚 DELIVERY & ROUTE STATUS",
            status_on_the_way: "On The Way",
            route_pickup_label: "Pickup Location",
            route_dest_label: "Destination",
            route_eta_label: "Estimated Delivery",
            btn_open_route_map: "Open Interactive Route Map",
            footer_slogan: "Connecting Farms. Empowering Farmers.",
            footer_copy: "© 2026 KhetKonnect | Built for Smart India Hackathon",
            login_welcome: "Welcome Back!",
            login_sub: "Login to your KhetKonnect account.",
            lbl_email: "Email Address",
            lbl_password: "Password",
            no_account_text: "Don't have an account?",
            signup_title: "Create Account",
            signup_sub: "Join India's digital agriculture ecosystem.",
            lbl_full_name: "Full Name",
            lbl_phone: "Phone Number",
            lbl_account_type: "Account Type",
            opt_select_type: "Select Account Type",
            opt_farmer: "Farmer (किसान)",
            opt_fpo: "FPO (Farmer Producer Org)",
            opt_consumer: "Consumer / Buyer (ग्राहक)",
            opt_bulk_buyer: "Bulk Buyer / Retailer",
            opt_logistics: "Logistics Partner",
            btn_create_account: "Create Account",
            already_account_text: "Already have an account?",
            route_modal_title: "Smart Route & Navigation Planner",
            route_modal_sub: "Calculate optimal farm-to-market dispatch routes, distance, and transit time.",
            route_lbl_origin: "🚜 Farm / Pickup Origin:",
            route_lbl_dest: "🛒 Buyer / Delivery Destination:",
            route_quick_hubs: "Quick Agricultural Corridors:",
            route_vehicle_type: "🚛 Vehicle & Cold-Chain Type:",
            btn_calc_route: "Calculate Optimized Route",
            metric_distance: "Distance",
            metric_time: "Estimated Time",
            metric_freight: "Est. Freight Cost",
            metric_co2: "CO₂ Reduction",
            btn_book_logistics: "Book Dispatch & Save Waybill",
            farmer_dash_title: "Farmer Produce Management Center",
            farmer_dash_sub: "List your fresh harvest, manage real-time inventory, and track incoming buyer orders.",
            tab_add_produce: "➕ List New Harvest Produce",
            tab_my_listings: "🌾 My Farm Listings",
            tab_orders: "📦 Incoming Orders",
            lbl_crop_name: "Crop / Produce Name *",
            lbl_crop_category: "Category *",
            lbl_crop_price: "Farmer Direct Price (₹ per unit) *",
            lbl_crop_stock: "Available Quantity *",
            lbl_farm_loc: "Farm Origin Location *",
            lbl_crop_emoji: "Select Visual Emoji Icon",
            lbl_crop_desc: "Harvest Description & Quality Notes",
            btn_publish_produce: "🚀 Publish Produce to KhetKonnect Marketplace",
            cart_title: "Your Farm Direct Cart",
            cart_sub: "100% of payment goes directly to verified farmers and FPOs.",
            cart_subtotal: "Produce Subtotal:",
            cart_delivery: "Direct Logistics & Delivery:",
            cart_total: "Grand Total:",
            checkout_address_title: "Delivery & Contact Details",
            btn_place_order: "✅ Confirm Direct Farm Order",
            voice_listening_title: "Listening... Speak now",
            btn_stop_listening: "Stop Listening"
        },
        hi: {
            nav_home: "मुख्य पृष्ठ",
            nav_marketplace: "मंडी बाज़ार",
            nav_solutions: "समाधान",
            nav_ai: "एआई अंतर्दृष्टि",
            nav_logistics: "लॉजिस्टिक्स",
            btn_voice: "आवाज़ (बोलें)",
            btn_login: "लॉगिन",
            btn_signup: "साइन अप",
            btn_logout: "लॉगआउट",
            btn_favorites: "पसंदीदा",
            menu_farmer_dashboard: "किसान डैशबोर्ड",
            menu_my_orders: "मेरे ऑर्डर",
            menu_favorites: "मेरी पसंदीदा फसलें",
            menu_profile: "मेरी प्रोफ़ाइल",
            hero_tag: "🌱 डिजिटल कृषि बाज़ार",
            hero_title: "सीधे <span>खेत</span> से<br>आपकी थाली तक।",
            hero_description: "खेतकनेक्ट किसानों और एफपीओ को सीधे उपभोक्ताओं और थोक खरीदारों से जोड़ता है, बिचौलियों को हटाकर सभी को उचित मूल्य दिलाता है।",
            hero_btn_explore: "मंडी बाज़ार देखें",
            hero_btn_farmer: "👨‍🌾 किसान पंजीकरण",
            stat_farmers: "जुड़े किसान",
            stat_earnings: "बेहतर कमाई",
            stat_prices: "कम दाम",
            hero_price_tag: "किसान का सीधा दाम",
            hero_income_tag: "किसान की बेहतर आय",
            hero_smart_delivery: "स्मार्ट डिलीवरी",
            hero_route_sub: "एआई अनुकूलित मार्ग",
            problem_tag: "समस्या",
            problem_title: "बहुत सारे बिचौलिए।<br>किसानों को कम आय।",
            problem_description: "पारंपरिक कृषि आपूर्ति श्रृंखला में कई बिचौलिए शामिल होते हैं। किसानों को कम मिलता है और उपभोक्ताओं को ज्यादा चुकाना पड़ता है।",
            problem_1_title: "किसानों की कम आय",
            problem_1_desc: "किसानों को अंतिम उपभोक्ता मूल्य का केवल एक छोटा सा हिस्सा मिलता है।",
            problem_2_title: "उपभोक्ताओं के लिए महंगा",
            problem_2_desc: "कई बिचौलिए कृषि उत्पादों की अंतिम कीमत बढ़ा देते हैं।",
            problem_3_title: "अकुशल परिवहन",
            problem_3_desc: "खराब लॉजिस्टिक्स के कारण परिवहन लागत बढ़ती है और फसल खराब होती है।",
            solution_tag: "हमारा समाधान",
            solution_title: "किसानों को सीधे खरीदारों से जोड़ना।",
            solution_desc: "खेतकनेक्ट एक पारदर्शी डिजिटल मंच प्रदान करता है जहां किसान अपनी उपज सीधे बेच सकते हैं।",
            solution_1_title: "प्रत्यक्ष बाज़ार",
            solution_1_desc: "किसान और एफपीओ बिना बिचौलियों के सीधे उत्पाद बेचते हैं।",
            solution_2_title: "एआई मांग पूर्वानुमान",
            solution_2_desc: "एआई फसल की मांग का पूर्वानुमान लगाकर सही निर्णय लेने में मदद करता है।",
            solution_3_title: "स्मार्ट लॉजिस्टिक्स",
            solution_3_desc: "मार्ग अनुकूलन से परिवहन लागत और समय दोनों की बचत होती है।",
            label_farmer: "किसान",
            label_consumer: "उपभोक्ता",
            market_tag: "खेतों से ताज़ा",
            market_title: "ताज़ा कृषि उत्पाद बाज़ार",
            market_desc: "सीधे किसानों से ताज़ा कृषि उपज खरीदें।",
            cat_all: "सभी",
            cat_veg: "सब्जियां",
            cat_fruits: "फल",
            cat_grains: "अनाज",
            cat_others: "अन्य",
            btn_add_crop: "किसान: नई फसल जोड़ें",
            btn_add_cart: "कार्ट में जोड़ें",
            badge_verified: "✓ सत्यापित किसान",
            badge_fpo: "✓ एफपीओ सत्यापित",
            ai_tag: "एआई एवं डेटा तकनीक",
            ai_title: "एआई से लें समझदारी भरे फैसले।",
            ai_desc: "एआई बाज़ार की मांग और मौसमी रुझानों का विश्लेषण करके किसानों को बेहतर योजना बनाने में मदद करता है।",
            ai_pt_1: "✓ मांग पूर्वानुमान",
            ai_pt_2: "✓ मूल्य रुझान विश्लेषण",
            ai_pt_3: "✓ फसल अनुशंसा",
            ai_pt_4: "✓ बाज़ार जानकारी",
            ai_select_crop: "मांग देखने के लिए फसल चुनें:",
            ai_header_sub: "एआई बाज़ार विश्लेषण",
            ai_header_title: "मांग पूर्वानुमान",
            ai_forecast_label: "अनुमानित मांग वृद्धि",
            ai_advice_tag: "💡 एआई सुझाव:",
            ai_advice_default: "कटाई का सर्वोत्तम समय: अगले 48 घंटे। नजदीकी शहरी मंडियों में भारी मांग का अनुमान।",
            logistics_tag: "स्मार्ट लॉजिस्टिक्स एवं रूट प्लानिंग",
            logistics_title: "बेहतर रास्ते।<br>तेज़ डिलीवरी।",
            logistics_desc: "खेतकनेक्ट किसानों को लॉजिस्टिक्स पार्टनर्स से जोड़ता है और रूट अनुकूलन द्वारा लागत कम करता है।",
            btn_explore_logistics: "लॉजिस्टिक्स एवं रूट प्लानर देखें →",
            logistics_status_tag: "🚚 डिलीवरी एवं रूट स्थिति",
            status_on_the_way: "मार्ग में है (चालू)",
            route_pickup_label: "पिकअप स्थान (खेत)",
            route_dest_label: "गंतव्य (मंडी/खरीदार)",
            route_eta_label: "अनुमानित समय",
            btn_open_route_map: "इंटरैक्टिव रूट मैप खोलें",
            footer_slogan: "खेतों को जोड़ना। किसानों को सशक्त बनाना।",
            footer_copy: "© 2026 खेतकनेक्ट | स्मार्ट इंडिया हैकथॉन के लिए निर्मित",
            login_welcome: "वापसी पर स्वागत है!",
            login_sub: "अपने खेतकनेक्ट खाते में लॉगिन करें।",
            lbl_email: "ईमेल पता",
            lbl_password: "पासवर्ड",
            no_account_text: "खाता नहीं है?",
            signup_title: "खाता बनाएं",
            signup_sub: "भारत के डिजिटल कृषि तंत्र से जुड़ें।",
            lbl_full_name: "पूरा नाम",
            lbl_phone: "फ़ोन नंबर",
            lbl_account_type: "खाते का प्रकार",
            opt_select_type: "खाता प्रकार चुनें",
            opt_farmer: "किसान (Farmer)",
            opt_fpo: "एफपीओ (FPO)",
            opt_consumer: "उपभोक्ता (Consumer)",
            opt_bulk_buyer: "थोक खरीदार (Bulk Buyer)",
            opt_logistics: "लॉजिस्टिक्स पार्टनर",
            btn_create_account: "खाता बनाएं",
            already_account_text: "पहले से खाता है?",
            route_modal_title: "स्मार्ट रूट एवं नेविगेशन प्लानर",
            route_modal_sub: "खेत से बाज़ार तक का सबसे छोटा रास्ता, दूरी और समय की गणना करें।",
            route_lbl_origin: "🚜 खेत / पिकअप स्थान:",
            route_lbl_dest: "🛒 खरीदार / मंडी गंतव्य:",
            route_quick_hubs: "त्वरित कृषि गलियारे:",
            route_vehicle_type: "🚛 वाहन और कोल्ड-चेन प्रकार:",
            btn_calc_route: "अनुकूलित रूट की गणना करें",
            metric_distance: "दूरी",
            metric_time: "अनुमानित समय",
            metric_freight: "अनुमानित भाड़ा",
            metric_co2: "कार्बन बचत",
            btn_book_logistics: "डिस्पैच बुक करें और बिल बनाएं",
            farmer_dash_title: "किसान उपज प्रबंधन केंद्र",
            farmer_dash_sub: "अपनी ताज़ा फसल सूचीबद्ध करें, स्टॉक प्रबंधित करें और खरीदार ऑर्डर ट्रैक करें।",
            tab_add_produce: "➕ नई फसल जोड़ें",
            tab_my_listings: "🌾 मेरी फसलें",
            tab_orders: "📦 प्राप्त ऑर्डर",
            lbl_crop_name: "फसल / उत्पाद का नाम *",
            lbl_crop_category: "श्रेणी *",
            lbl_crop_price: "सीधा दाम (₹ प्रति किलो) *",
            lbl_crop_stock: "उपलब्ध मात्रा *",
            lbl_farm_loc: "खेत का स्थान *",
            lbl_crop_emoji: "प्रतीक चिन्ह (Emoji) चुनें",
            lbl_crop_desc: "फसल विवरण और गुणवत्ता नोट्स",
            btn_publish_produce: "🚀 खेतकनेक्ट मंडी में प्रकाशित करें",
            cart_title: "आपकी ताज़ा टोकरी (Cart)",
            cart_sub: "100% भुगतान सीधे सत्यापित किसानों तक पहुंचता है।",
            cart_subtotal: "उत्पाद मूल्य:",
            cart_delivery: "सीधा परिवहन एवं डिलीवरी:",
            cart_total: "कुल राशि:",
            checkout_address_title: "डिलीवरी एवं संपर्क विवरण",
            btn_place_order: "✅ आर्डर की पुष्टि करें",
            voice_listening_title: "सुन रहा हूँ... बोलिए",
            btn_stop_listening: "सुनना बंद करें"
        },
        or: {
            nav_home: "ମୁଖ୍ୟ ପୃଷ୍ଠା",
            nav_marketplace: "ମଣ୍ଡି ବଜାର",
            nav_solutions: "ସମାଧାନ",
            nav_ai: "ଏଆଇ ପୂର୍ବାନୁମାନ",
            nav_logistics: "ଲଜିଷ୍ଟିକ୍ସ",
            btn_voice: "ସ୍ୱର (କୁହନ୍ତୁ)",
            btn_login: "ଲଗଇନ",
            btn_signup: "ସାଇନ ଅପ",
            btn_logout: "ଲଗଆଉଟ",
            btn_favorites: "ପସନ୍ଦ",
            menu_farmer_dashboard: "ଚାଷୀ ଡ୍ୟାସବୋର୍ଡ",
            menu_my_orders: "ମୋର ଅର୍ଡର",
            menu_favorites: "ମୋର ପସନ୍ଦ",
            menu_profile: "ମୋର ପ୍ରୋଫାଇଲ",
            hero_tag: "🌱 ଡିଜିଟାଲ କୃଷି ମାର୍କେଟପ୍ଲେସ",
            hero_title: "ସିଧାସଳଖ <span>କ୍ଷେତରୁ</span><br>ଆପଣଙ୍କ ଥାଳିକୁ।",
            hero_description: "ଖେତକନେକ୍ଟ ଚାଷୀମାନଙ୍କୁ ସିଧାସଳଖ ଗ୍ରାହକଙ୍କ ସହିତ ଯୋଡି ଉଚିତ ମୂଲ୍ୟ ପ୍ରଦାନ କରେ।",
            hero_btn_explore: "ମଣ୍ଡି ବଜାର ଦେଖନ୍ତୁ",
            hero_btn_farmer: "👨‍🌾 ଚାଷୀ ପଞ୍ଜୀକରଣ",
            stat_farmers: "ଯୋଡି ହୋଇଥିବା ଚାଷୀ",
            stat_earnings: "ଅଧିକ ରୋଜଗାର",
            stat_prices: "କମ୍ ଦର",
            btn_add_crop: "ନୂଆ ଫସଲ ଯୋଡନ୍ତୁ",
            btn_add_cart: "କାର୍ଟରେ ଯୋଡନ୍ତୁ",
            btn_calc_route: "ରାସ୍ତା ହିସାବ କରନ୍ତୁ",
            btn_place_order: "ଅର୍ଡର ନିଶ୍ଚିତ କରନ୍ତୁ"
        },
        pa: {
            nav_home: "ਮੁੱਖ ਪੰਨਾ",
            nav_marketplace: "ਮੰਡੀ ਬਜ਼ਾਰ",
            nav_solutions: "ਹੱਲ",
            nav_ai: "ਏਆਈ ਅਨੁਮਾਨ",
            nav_logistics: "ਆਵਾਜਾਈ",
            btn_voice: "ਅਵਾਜ਼ (ਬੋਲੋ)",
            btn_login: "ਲਾਗਇਨ",
            btn_signup: "ਸਾਈਨ ਅੱਪ",
            btn_logout: "ਲਾਗਆਉਟ",
            btn_favorites: "ਪਸੰਦੀਦਾ",
            menu_farmer_dashboard: "ਕਿਸਾਨ ਡੈਸ਼ਬੋਰਡ",
            menu_my_orders: "ਮੇਰੇ ਆਰਡਰ",
            hero_tag: "🌱 ਡਿਜੀਟਲ ਖੇਤੀਬਾੜੀ ਮਾਰਕੀਟ",
            hero_title: "ਸਿੱਧਾ <span>ਖੇਤਾਂ</span> ਤੋਂ<br>ਤੁਹਾਡੀ ਥਾਲੀ ਤੱਕ।",
            hero_description: "ਖੇਤਕਨੈਕਟ ਕਿਸਾਨਾਂ ਨੂੰ ਸਿੱਧਾ ਖਪਤਕਾਰਾਂ ਨਾਲ ਜੋੜਦਾ ਹੈ ਤਾਂ ਜੋ ਵਧੀਆ ਮੁੱਲ ਮਿਲ ਸਕੇ।",
            hero_btn_explore: "ਮੰਡੀ ਵੇਖੋ",
            hero_btn_farmer: "👨‍🌾 ਕਿਸਾਨ ਰਜਿਸਟ੍ਰੇਸ਼ਨ",
            stat_farmers: "ਜੁੜੇ ਕਿਸਾਨ",
            stat_earnings: "ਵਧੀਆ ਕਮਾਈ",
            stat_prices: "ਘੱਟ ਕੀਮਤਾਂ",
            btn_add_crop: "ਨਵੀਂ ਫਸਲ ਸ਼ਾਮਲ ਕਰੋ",
            btn_add_cart: "ਕਾਰਟ ਵਿੱਚ ਸ਼ਾਮਲ ਕਰੋ",
            btn_calc_route: "ਰੂਟ ਦਾ ਹਿਸਾਬ ਲਗਾਓ",
            btn_place_order: "ਆਰਡਰ ਪੱਕਾ ਕਰੋ"
        },
        mr: {
            nav_home: "मुख्यपृष्ठ",
            nav_marketplace: "बाजारपेठ",
            nav_solutions: "उपाय",
            nav_ai: "एआय अंदाज",
            nav_logistics: "वाहतूक व्यवस्था",
            btn_voice: "आवाज (बोला)",
            btn_login: "लॉगिन",
            btn_signup: "साइन अप",
            btn_logout: "लॉगआउट",
            btn_favorites: "आवडीचे",
            menu_farmer_dashboard: "शेतकरी डॅशबोर्ड",
            menu_my_orders: "माझे ऑर्डर्स",
            hero_tag: "🌱 डिजिटल कृषी बाजारपेठ",
            hero_title: "थेट <span>शेतातून</span><br>तुमच्या ताटापर्यंत.",
            hero_description: "शेतकऱ्यांना थेट ग्राहकांशी जोडून योग्य भाव मिळवून देणारे व्यासपीठ.",
            hero_btn_explore: "बाजारपेठ पहा",
            hero_btn_farmer: "👨‍🌾 शेतकरी नोंदणी",
            stat_farmers: "जोडलेले शेतकरी",
            stat_earnings: "जास्त उत्पन्न",
            stat_prices: "कमी दर",
            btn_add_crop: "शेतकरी: नवीन पीक जोडा",
            btn_add_cart: "कार्टमध्ये जोडा",
            btn_calc_route: "मार्ग शोधा",
            btn_place_order: "ऑर्डर निश्चित करा"
        },
        bn: {
            nav_home: "হোম",
            nav_marketplace: "বাজার",
            nav_solutions: "সমাধান",
            nav_ai: "এআই বিশ্লেষণ",
            nav_logistics: "লজিস্টিকস",
            btn_voice: "ভয়েস (বলুন)",
            btn_login: "লগইন",
            btn_signup: "সাইন আপ",
            btn_logout: "লগআউট",
            btn_favorites: "পছন্দের",
            menu_farmer_dashboard: "কৃষক ড্যাশবোর্ড",
            menu_my_orders: "আমার অর্ডার",
            hero_tag: "🌱 ডিজিটাল কৃষি মার্কেটপ্লেস",
            hero_title: "সরাসরি <span>খামার</span> থেকে<br>আপনার পাতে।",
            hero_description: "ক্ষেতকানেক্ট কৃষকদের সরাসরি ক্রেতাদের সাথে যুক্ত করে ন্যায্য মূল্য নিশ্চিত করে।",
            hero_btn_explore: "মার্কেটপ্লেস দেখুন",
            hero_btn_farmer: "👨‍🌾 কৃষক নিবন্ধন",
            stat_farmers: "যুক্ত কৃষক",
            stat_earnings: "বেশি আয়",
            stat_prices: "কম দাম",
            btn_add_crop: "নতুন ফসল যোগ করুন",
            btn_add_cart: "কার্টে যোগ করুন",
            btn_calc_route: "রুট গণনা করুন",
            btn_place_order: "অর্ডার কনফার্ম করুন"
        },
        te: {
            nav_home: "హోమ్",
            nav_marketplace: "మార్కెట్",
            nav_solutions: "పరిష్కారాలు",
            nav_ai: "ఏఐ అంచనాలు",
            nav_logistics: "రవాణా",
            btn_voice: "వాయిస్ (మాట్లాడండి)",
            btn_login: "లాగిన్",
            btn_signup: "సైన్ అప్",
            btn_logout: "లాగౌట్",
            btn_favorites: "ఇష్టమైనవి",
            menu_farmer_dashboard: "రైతు డాష్‌బోర్డ్",
            menu_my_orders: "నా ఆర్డర్లు",
            hero_tag: "🌱 డిజిటల్ వ్యవసాయ మార్కెట్",
            hero_title: "నేరుగా <span>పొలం</span> నుండి<br>మీ ఇంటికి.",
            hero_description: "రైతులను నేరుగా వినియోగదారులతో అనుసంధానించే వేదిక.",
            hero_btn_explore: "మార్కెట్ చూడండి",
            hero_btn_farmer: "👨‍🌾 రైతుగా నమోదు",
            stat_farmers: "కలిసిన రైతులు",
            stat_earnings: "మంచి రాబడి",
            stat_prices: "తక్కువ ధరలు",
            btn_add_crop: "కొత్త పంట జోడించండి",
            btn_add_cart: "కార్ట్‌కు జోడించండి",
            btn_calc_route: "రూట్ లెక్కించండి",
            btn_place_order: "ఆర్డర్ ఖరారు చేయండి"
        },
        ta: {
            nav_home: "முகப்பு",
            nav_marketplace: "சந்தை",
            nav_solutions: "தீர்வுகள்",
            nav_ai: "ஏஐ நுண்ணறிவு",
            nav_logistics: "போக்குவரத்து",
            btn_voice: "குரல் (பேசுங்கள்)",
            btn_login: "உள்நுழைக",
            btn_signup: "பதிவு செய்க",
            btn_logout: "வெளியேறு",
            btn_favorites: "விருப்பங்கள்",
            menu_farmer_dashboard: "விவசாயி டாஷ்போர்டு",
            menu_my_orders: "என் ஆர்டர்கள்",
            hero_tag: "🌱 டிஜிட்டல் வேளாண் சந்தை",
            hero_title: "நேரடியாக <span>பண்ணையில்</span> இருந்து<br>உங்கள் வீட்டிற்கு.",
            hero_description: "விவசாயிகளை நுகர்வோருடன் நேரடியாக இணைக்கும் சிறந்த தளம்.",
            hero_btn_explore: "சந்தையைக் காண்க",
            hero_btn_farmer: "👨‍🌾 விவசாயி பதிவு",
            stat_farmers: "இணைந்த விவசாயிகள்",
            stat_earnings: "அதிக வருமானம்",
            stat_prices: "குறைந்த விலை",
            btn_add_crop: "புதிய பயிர் சேர்",
            btn_add_cart: "கார்ட்டில் சேர்",
            btn_calc_route: "வழியை கணக்கிடு",
            btn_place_order: "ஆர்டர் உறுதி செய்"
        }
    };

    let currentLanguage = LocalDB.get("language") || "en";

    function setLanguage(langCode) {
        if (!TRANSLATIONS[langCode]) {
            langCode = "en";
        }
        currentLanguage = langCode;
        LocalDB.set("language", langCode);

        const dict = TRANSLATIONS[langCode];
        const defaultDict = TRANSLATIONS["en"];

        document.querySelectorAll("[data-i18n]").forEach(function (el) {
            const key = el.getAttribute("data-i18n");
            const text = dict[key] || defaultDict[key];
            if (text) {
                if (text.includes("<") && text.includes(">")) {
                    el.innerHTML = text;
                } else {
                    el.textContent = text;
                }
            }
        });

        const langSelect = document.getElementById("languageSelect");
        if (langSelect && langSelect.value !== langCode) {
            langSelect.value = langCode;
        }

        console.log(`🌐 Language switched to: ${langCode}`);
    }

    const langSelector = document.getElementById("languageSelect");
    if (langSelector) {
        langSelector.value = currentLanguage;
        langSelector.addEventListener("change", function () {
            setLanguage(this.value);
            showToast(`🌐 Language changed to ${this.options[this.selectedIndex].text}`);
        });
    }

    /* ====================================================================
       3. AUTHENTICATION & USER MANAGEMENT
       ==================================================================== */
    let currentUser = LocalDB.get("currentUser") || null;

    const authModal = document.getElementById("authModal");
    const loginButton = document.getElementById("loginButton");
    const signupButton = document.getElementById("signupButton");
    const farmerRegisterButton = document.getElementById("farmerRegisterButton");
    const closeButton = document.getElementById("closeButton");
    const loginForm = document.getElementById("loginForm");
    const signupForm = document.getElementById("signupForm");
    const showSignupButton = document.getElementById("showSignupButton");
    const showLoginButton = document.getElementById("showLoginButton");
    const loginFormElement = document.getElementById("loginFormElement");
    const signupFormElement = document.getElementById("signupFormElement");
    const authActionsContainer = document.getElementById("authActionsContainer");
    const userProfileBadge = document.getElementById("userProfileBadge");
    const userMenuButton = document.getElementById("userMenuButton");
    const userDropdownMenu = document.getElementById("userDropdownMenu");
    const userNameDisplay = document.getElementById("userNameDisplay");
    const userEmailDisplay = document.getElementById("userEmailDisplay");
    const userRoleBadge = document.getElementById("userRoleBadge");
    const userLogoutBtn = document.getElementById("userLogoutBtn");
    const openFarmerDashboardBtn = document.getElementById("openFarmerDashboardBtn");
    const openBuyerOrdersBtn = document.getElementById("openBuyerOrdersBtn");
    const openBuyerFavoritesBtn = document.getElementById("openBuyerFavoritesBtn");
    const openBuyerProfileBtn = document.getElementById("openBuyerProfileBtn");

    function updateAuthUI() {
        if (currentUser) {
            if (authActionsContainer) authActionsContainer.classList.add("hidden");
            if (userProfileBadge) userProfileBadge.classList.remove("hidden");
            if (userNameDisplay) userNameDisplay.textContent = currentUser.full_name || "User";
            if (userEmailDisplay) userEmailDisplay.textContent = currentUser.email || "";
            if (userRoleBadge) {
                userRoleBadge.textContent = (currentUser.account_type || "consumer").toUpperCase();
            }
            if (openFarmerDashboardBtn) {
                if (currentUser.account_type === "farmer" || currentUser.account_type === "fpo") {
                    openFarmerDashboardBtn.classList.remove("hidden");
                } else {
                    openFarmerDashboardBtn.classList.add("hidden");
                }
            }
        } else {
            if (authActionsContainer) authActionsContainer.classList.remove("hidden");
            if (userProfileBadge) userProfileBadge.classList.add("hidden");
            if (userDropdownMenu) userDropdownMenu.classList.add("hidden");
        }
    }

    function openLogin() {
        if (!authModal) return;
        authModal.style.display = "flex";
        if (loginForm) loginForm.classList.remove("hidden");
        if (signupForm) signupForm.classList.add("hidden");
    }

    function openSignup(preferredType) {
        if (!authModal) return;
        authModal.style.display = "flex";
        if (signupForm) signupForm.classList.remove("hidden");
        if (loginForm) loginForm.classList.add("hidden");
        if (preferredType) {
            const accSelect = document.getElementById("accountType");
            if (accSelect) accSelect.value = preferredType;
        }
    }

    function closeAuth() {
        if (authModal) authModal.style.display = "none";
    }

    if (loginButton) loginButton.addEventListener("click", openLogin);
    if (signupButton) signupButton.addEventListener("click", () => openSignup("consumer"));
    if (farmerRegisterButton) farmerRegisterButton.addEventListener("click", () => openSignup("farmer"));
    if (closeButton) closeButton.addEventListener("click", closeAuth);
    if (showSignupButton) showSignupButton.addEventListener("click", () => openSignup());
    if (showLoginButton) showLoginButton.addEventListener("click", openLogin);

    if (userMenuButton && userDropdownMenu) {
        userMenuButton.addEventListener("click", function (e) {
            e.stopPropagation();
            userDropdownMenu.classList.toggle("hidden");
        });
        document.addEventListener("click", function () {
            if (userDropdownMenu) userDropdownMenu.classList.add("hidden");
        });
    }

    if (userLogoutBtn) {
        userLogoutBtn.addEventListener("click", async function () {
            if (isSupabaseConfigured && supabaseClient) {
                await supabaseClient.auth.signOut();
            }
            currentUser = null;
            LocalDB.set("currentUser", null);
            updateAuthUI();
            showToast("Logged out successfully.");
        });
    }

    if (authModal) {
        authModal.addEventListener("click", function (event) {
            if (event.target === authModal) closeAuth();
        });
    }

    // Login Form Submit
    if (loginFormElement) {
        loginFormElement.addEventListener("submit", async function (e) {
            e.preventDefault();
            const email = document.getElementById("loginEmail").value.trim();
            const password = document.getElementById("loginPassword").value;

            showToast("Authenticating...");

            if (isSupabaseConfigured && supabaseClient) {
                try {
                    const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
                    if (error) throw error;
                    currentUser = {
                        id: data.user.id,
                        email: data.user.email,
                        full_name: data.user.user_metadata?.full_name || email.split("@")[0],
                        account_type: data.user.user_metadata?.account_type || "consumer"
                    };
                } catch (err) {
                    console.warn("Supabase auth failed, fallback to local:", err.message);
                    currentUser = {
                        id: "usr-" + Date.now(),
                        email: email,
                        full_name: email.split("@")[0],
                        account_type: email.includes("farmer") ? "farmer" : "consumer"
                    };
                }
            } else {
                currentUser = {
                    id: "usr-" + Date.now(),
                    email: email,
                    full_name: email.split("@")[0],
                    account_type: email.includes("farmer") ? "farmer" : "consumer"
                };
            }

            LocalDB.set("currentUser", currentUser);
            updateAuthUI();
            showToast(`Welcome back, ${currentUser.full_name}!`);
            loginFormElement.reset();
            setTimeout(closeAuth, 600);
        });
    }

    // Signup Form Submit
    if (signupFormElement) {
        signupFormElement.addEventListener("submit", async function (e) {
            e.preventDefault();
            const name = document.getElementById("signupName").value.trim();
            const email = document.getElementById("signupEmail").value.trim();
            const phone = document.getElementById("signupPhone").value.trim();
            const accountType = document.getElementById("accountType").value;
            const password = document.getElementById("signupPassword").value;

            showToast("Creating KhetKonnect account...");

            if (isSupabaseConfigured && supabaseClient) {
                try {
                    const { data, error } = await supabaseClient.auth.signUp({
                        email,
                        password,
                        options: {
                            data: { full_name: name, phone, account_type: accountType }
                        }
                    });
                    if (error) throw error;
                    currentUser = {
                        id: data.user ? data.user.id : "usr-" + Date.now(),
                        email,
                        full_name: name,
                        phone,
                        account_type: accountType
                    };
                } catch (err) {
                    console.warn("Supabase signup fallback:", err.message);
                    currentUser = {
                        id: "usr-" + Date.now(),
                        email,
                        full_name: name,
                        phone,
                        account_type: accountType
                    };
                }
            } else {
                currentUser = {
                    id: "usr-" + Date.now(),
                    email,
                    full_name: name,
                    phone,
                    account_type: accountType
                };
            }

            LocalDB.set("currentUser", currentUser);
            updateAuthUI();
            showToast(`Account created! Welcome, ${name}.`);
            signupFormElement.reset();
            setTimeout(closeAuth, 600);

            if (accountType === "farmer" || accountType === "fpo") {
                setTimeout(openFarmerDashboard, 1000);
            }
        });
    }

    /* ====================================================================
       4. BUYER MARKETPLACE: SEARCH, FILTERS & FAVORITES
       ==================================================================== */
    const productGridContainer = document.getElementById("productGridContainer");
    const produceSearchInput = document.getElementById("produceSearchInput");
    const clearSearchBtn = document.getElementById("clearSearchBtn");
    const searchVoiceBtn = document.getElementById("searchVoiceBtn");
    const resultsCountDisplay = document.getElementById("resultsCountDisplay");
    const resetFilterLink = document.getElementById("resetFilterLink");
    const filterButtons = document.querySelectorAll(".filter");
    const favCountElement = document.getElementById("favCount");
    const favoritesButton = document.getElementById("favoritesButton");

    let currentCategoryFilter = "all";
    let currentSearchQuery = "";
    let favoritesList = LocalDB.get("favorites", ["prod-1", "prod-3"]);

    function updateFavoritesBadge() {
        if (favCountElement) {
            favCountElement.textContent = favoritesList.length;
        }
        LocalDB.set("favorites", favoritesList);
    }

    function toggleFavorite(productId) {
        const index = favoritesList.indexOf(productId);
        if (index > -1) {
            favoritesList.splice(index, 1);
            showToast("Removed from favorites 🤍");
        } else {
            favoritesList.push(productId);
            showToast("Saved to favorites! ❤️");
        }
        updateFavoritesBadge();
        renderMarketplaceProducts();
        renderFavoritesModalList();
    }

    function renderMarketplaceProducts() {
        const products = LocalDB.get("products", DEFAULT_PRODUCTS);
        if (!productGridContainer) return;

        productGridContainer.innerHTML = "";

        const query = currentSearchQuery.toLowerCase().trim();

        const filtered = products.filter(p => {
            // Category filter
            const matchesCat = currentCategoryFilter === "all" || p.category === currentCategoryFilter;
            if (!matchesCat) return false;

            // Search filter
            if (!query) return true;
            const nameMatch = (p.name || "").toLowerCase().includes(query);
            const farmerMatch = (p.farmer_name || "").toLowerCase().includes(query);
            const locMatch = (p.location || "").toLowerCase().includes(query);
            const catMatch = (p.category || "").toLowerCase().includes(query);
            return nameMatch || farmerMatch || locMatch || catMatch;
        });

        // Update result status
        if (resultsCountDisplay) {
            resultsCountDisplay.textContent = `Showing ${filtered.length} farm fresh item${filtered.length === 1 ? "" : "s"}`;
        }

        if (filtered.length === 0) {
            productGridContainer.innerHTML = `
                <div class="empty-produce-state">
                    <div class="empty-icon">🌱</div>
                    <h3>No produce matched your search</h3>
                    <p>Try searching for another crop or reset your category filters.</p>
                </div>
            `;
            return;
        }

        filtered.forEach(prod => {
            const isFav = favoritesList.includes(prod.id);
            const card = document.createElement("div");
            card.className = "product-card";
            card.setAttribute("data-category", prod.category);
            card.setAttribute("data-product-id", prod.id);

            card.innerHTML = `
                <button class="product-fav-toggle ${isFav ? "is-fav" : ""}" data-fav-id="${prod.id}" title="${isFav ? "Remove Favorite" : "Add to Favorites"}">
                    ${isFav ? "❤️" : "🤍"}
                </button>
                <div class="product-image">${prod.image_emoji || "🌾"}</div>
                <div class="product-details">
                    <div class="product-tags">
                        <span class="verified-tag">${prod.is_verified ? "✓ Verified Farmer" : "✓ Farm Fresh"}</span>
                        <span class="stock-tag">${prod.stock_qty || 100} ${prod.unit || "kg"} in stock</span>
                    </div>
                    <h3 class="product-title">${prod.name}</h3>
                    <div class="product-meta-row">
                        <span>📍 ${prod.location || "Farm Gate"}</span>
                    </div>
                    <div class="product-farmer-meta">
                        <span>👨‍🌾 ${prod.farmer_name || "Local Farmer"}</span>
                    </div>
                    <div class="product-price-box">
                        <strong>₹${prod.price_per_kg}</strong>
                        <span>/ ${prod.unit || "kg"}</span>
                    </div>
                    <div class="product-actions-group">
                        <button class="view-btn" data-view-id="${prod.id}">
                            👁️ View
                        </button>
                        <button class="add-cart" data-id="${prod.id}" data-name="${prod.name}" data-price="${prod.price_per_kg}" data-emoji="${prod.image_emoji || "🌾"}" data-unit="${prod.unit || "kg"}">
                            🛒 Add
                        </button>
                    </div>
                </div>
            `;
            productGridContainer.appendChild(card);
        });

        // Event listeners for Favorite heart buttons
        productGridContainer.querySelectorAll(".product-fav-toggle").forEach(btn => {
            btn.addEventListener("click", function (e) {
                e.stopPropagation();
                const id = this.getAttribute("data-fav-id");
                toggleFavorite(id);
            });
        });

        // Event listeners for View Details
        productGridContainer.querySelectorAll(".view-btn").forEach(btn => {
            btn.addEventListener("click", function (e) {
                e.stopPropagation();
                const id = this.getAttribute("data-view-id");
                openProductDetails(id);
            });
        });

        // Event listeners for Quick Add to Cart
        productGridContainer.querySelectorAll(".add-cart").forEach(button => {
            button.addEventListener("click", function (e) {
                e.stopPropagation();
                const id = this.getAttribute("data-id");
                const name = this.getAttribute("data-name");
                const price = parseFloat(this.getAttribute("data-price"));
                const emoji = this.getAttribute("data-emoji");
                const unit = this.getAttribute("data-unit") || "kg";
                addToCart({ id, name, price, emoji, unit, quantity: 1 });
            });
        });
    }

    // Search event handlers
    if (produceSearchInput) {
        produceSearchInput.addEventListener("input", function () {
            currentSearchQuery = this.value;
            if (clearSearchBtn) {
                clearSearchBtn.style.display = currentSearchQuery ? "block" : "none";
            }
            renderMarketplaceProducts();
        });
    }

    if (clearSearchBtn) {
        clearSearchBtn.addEventListener("click", function () {
            if (produceSearchInput) produceSearchInput.value = "";
            currentSearchQuery = "";
            clearSearchBtn.style.display = "none";
            renderMarketplaceProducts();
        });
    }

    if (searchVoiceBtn) {
        searchVoiceBtn.addEventListener("click", function () {
            startVoiceListening();
        });
    }

    if (resetFilterLink) {
        resetFilterLink.addEventListener("click", function () {
            currentCategoryFilter = "all";
            currentSearchQuery = "";
            if (produceSearchInput) produceSearchInput.value = "";
            if (clearSearchBtn) clearSearchBtn.style.display = "none";
            filterButtons.forEach(b => {
                if (b.getAttribute("data-category") === "all") b.classList.add("active");
                else b.classList.remove("active");
            });
            renderMarketplaceProducts();
        });
    }

    filterButtons.forEach(button => {
        button.addEventListener("click", function () {
            currentCategoryFilter = this.getAttribute("data-category");
            filterButtons.forEach(b => b.classList.remove("active"));
            this.classList.add("active");
            renderMarketplaceProducts();
        });
    });

    /* ====================================================================
       5. PRODUCT DETAILS MODAL (VIEW PRODUCE)
       ==================================================================== */
    const productDetailsModal = document.getElementById("productDetailsModal");
    const closeProductDetailsButton = document.getElementById("closeProductDetailsButton");
    const modalDetailEmoji = document.getElementById("modalDetailEmoji");
    const modalDetailBadge = document.getElementById("modalDetailBadge");
    const modalDetailFavBtn = document.getElementById("modalDetailFavBtn");
    const modalDetailTitle = document.getElementById("modalDetailTitle");
    const modalDetailPrice = document.getElementById("modalDetailPrice");
    const modalDetailUnit = document.getElementById("modalDetailUnit");
    const modalDetailStock = document.getElementById("modalDetailStock");
    const modalDetailFarmer = document.getElementById("modalDetailFarmer");
    const modalDetailLocation = document.getElementById("modalDetailLocation");
    const modalDetailDesc = document.getElementById("modalDetailDesc");
    const modalQtyMinus = document.getElementById("modalQtyMinus");
    const modalQtyPlus = document.getElementById("modalQtyPlus");
    const modalQtyInput = document.getElementById("modalQtyInput");
    const modalDetailAddToCartBtn = document.getElementById("modalDetailAddToCartBtn");

    let activeViewingProduct = null;

    function openProductDetails(productId) {
        const products = LocalDB.get("products", DEFAULT_PRODUCTS);
        const prod = products.find(p => p.id === productId);
        if (!prod || !productDetailsModal) return;

        activeViewingProduct = prod;

        if (modalDetailEmoji) modalDetailEmoji.textContent = prod.image_emoji || "🌾";
        if (modalDetailBadge) modalDetailBadge.textContent = prod.category || "Fresh Produce";
        if (modalDetailTitle) modalDetailTitle.textContent = prod.name;
        if (modalDetailPrice) modalDetailPrice.textContent = `₹${prod.price_per_kg}`;
        if (modalDetailUnit) modalDetailUnit.textContent = `/ ${prod.unit || "kg"}`;
        if (modalDetailStock) modalDetailStock.textContent = `${prod.stock_qty || 100} ${prod.unit || "kg"} in stock`;
        if (modalDetailFarmer) modalDetailFarmer.textContent = prod.farmer_name || "Verified Farmer";
        if (modalDetailLocation) modalDetailLocation.textContent = prod.location || "Local Farm Gate";
        if (modalDetailDesc) modalDetailDesc.textContent = prod.description || "Direct harvest fresh produce from verified farmer collective.";

        if (modalQtyInput) modalQtyInput.value = 1;

        const isFav = favoritesList.includes(prod.id);
        if (modalDetailFavBtn) {
            modalDetailFavBtn.textContent = isFav ? "❤️" : "🤍";
            modalDetailFavBtn.onclick = function () {
                toggleFavorite(prod.id);
                modalDetailFavBtn.textContent = favoritesList.includes(prod.id) ? "❤️" : "🤍";
            };
        }

        if (modalDetailAddToCartBtn) {
            modalDetailAddToCartBtn.onclick = function () {
                const qty = parseInt(modalQtyInput ? modalQtyInput.value : 1, 10) || 1;
                addToCart({
                    id: prod.id,
                    name: prod.name,
                    price: prod.price_per_kg,
                    emoji: prod.image_emoji || "🌾",
                    unit: prod.unit || "kg",
                    quantity: qty
                });
                closeProductDetails();
            };
        }

        productDetailsModal.style.display = "flex";
    }

    function closeProductDetails() {
        if (productDetailsModal) productDetailsModal.style.display = "none";
        activeViewingProduct = null;
    }

    if (closeProductDetailsButton) closeProductDetailsButton.addEventListener("click", closeProductDetails);
    if (productDetailsModal) {
        productDetailsModal.addEventListener("click", function (e) {
            if (e.target === productDetailsModal) closeProductDetails();
        });
    }

    if (modalQtyMinus && modalQtyInput) {
        modalQtyMinus.addEventListener("click", function () {
            let val = parseInt(modalQtyInput.value, 10) || 1;
            if (val > 1) modalQtyInput.value = val - 1;
        });
    }

    if (modalQtyPlus && modalQtyInput) {
        modalQtyPlus.addEventListener("click", function () {
            let val = parseInt(modalQtyInput.value, 10) || 1;
            modalQtyInput.value = val + 1;
        });
    }

    /* ====================================================================
       6. BUYER FAVORITES MODAL
       ==================================================================== */
    const favoritesModal = document.getElementById("favoritesModal");
    const closeFavoritesModalButton = document.getElementById("closeFavoritesModalButton");
    const favoritesListContainer = document.getElementById("favoritesListContainer");

    function openFavoritesModal() {
        if (!favoritesModal) return;
        renderFavoritesModalList();
        favoritesModal.style.display = "flex";
    }

    function closeFavoritesModal() {
        if (favoritesModal) favoritesModal.style.display = "none";
    }

    function renderFavoritesModalList() {
        if (!favoritesListContainer) return;
        favoritesListContainer.innerHTML = "";

        const products = LocalDB.get("products", DEFAULT_PRODUCTS);
        const favProducts = products.filter(p => favoritesList.includes(p.id));

        if (favProducts.length === 0) {
            favoritesListContainer.innerHTML = `
                <div style="text-align:center; padding: 40px 10px; color:#778578;">
                    <p style="font-size: 38px; margin-bottom: 8px;">🤍</p>
                    <h4>No favorites saved yet</h4>
                    <p style="font-size: 13px;">Tap the heart icon on any produce in the marketplace to save it here.</p>
                </div>
            `;
            return;
        }

        favProducts.forEach(prod => {
            const row = document.createElement("div");
            row.className = "favorite-item-card";
            row.innerHTML = `
                <div class="fav-item-main">
                    <span class="fav-emoji">${prod.image_emoji || "🌾"}</span>
                    <div class="fav-info">
                        <h4>${prod.name}</h4>
                        <p>₹${prod.price_per_kg}/${prod.unit || "kg"} • 📍 ${prod.location || "Farm"}</p>
                    </div>
                </div>
                <div class="fav-actions">
                    <button class="fav-add-btn" data-id="${prod.id}">🛒 Add</button>
                    <button class="fav-remove-btn" data-id="${prod.id}" title="Remove">✕</button>
                </div>
            `;
            favoritesListContainer.appendChild(row);
        });

        favoritesListContainer.querySelectorAll(".fav-add-btn").forEach(btn => {
            btn.addEventListener("click", function () {
                const id = this.getAttribute("data-id");
                const prod = favProducts.find(p => p.id === id);
                if (prod) {
                    addToCart({
                        id: prod.id,
                        name: prod.name,
                        price: prod.price_per_kg,
                        emoji: prod.image_emoji || "🌾",
                        unit: prod.unit || "kg",
                        quantity: 1
                    });
                }
            });
        });

        favoritesListContainer.querySelectorAll(".fav-remove-btn").forEach(btn => {
            btn.addEventListener("click", function () {
                const id = this.getAttribute("data-id");
                toggleFavorite(id);
            });
        });
    }

    if (favoritesButton) favoritesButton.addEventListener("click", openFavoritesModal);
    if (openBuyerFavoritesBtn) openBuyerFavoritesBtn.addEventListener("click", openFavoritesModal);
    if (closeFavoritesModalButton) closeFavoritesModalButton.addEventListener("click", closeFavoritesModal);
    if (favoritesModal) {
        favoritesModal.addEventListener("click", function (e) {
            if (e.target === favoritesModal) closeFavoritesModal();
        });
    }

    /* ====================================================================
       7. BUYER ORDERS MODAL
       ==================================================================== */
    const buyerOrdersModal = document.getElementById("buyerOrdersModal");
    const closeBuyerOrdersModalButton = document.getElementById("closeBuyerOrdersModalButton");
    const buyerOrdersListContainer = document.getElementById("buyerOrdersListContainer");

    function openBuyerOrdersModal() {
        if (!buyerOrdersModal) return;
        renderBuyerOrdersList();
        buyerOrdersModal.style.display = "flex";
    }

    function closeBuyerOrdersModal() {
        if (buyerOrdersModal) buyerOrdersModal.style.display = "none";
    }

    function renderBuyerOrdersList() {
        if (!buyerOrdersListContainer) return;
        buyerOrdersListContainer.innerHTML = "";

        const orders = LocalDB.get("orders", []);

        if (orders.length === 0) {
            buyerOrdersListContainer.innerHTML = `
                <div style="text-align:center; padding: 40px 10px; color:#778578;">
                    <p style="font-size: 38px; margin-bottom: 8px;">📦</p>
                    <h4>No orders yet</h4>
                    <p style="font-size: 13px;">Place your first farm-direct produce order from the marketplace!</p>
                </div>
            `;
            return;
        }

        orders.forEach(ord => {
            const dateStr = ord.created_at ? new Date(ord.created_at).toLocaleDateString("en-IN", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "Today";
            const itemsHtml = (ord.items || []).map(i => `
                <div class="order-item-line">
                    <span>${i.name} × ${i.quantity}kg</span>
                    <span>₹${i.total || (i.unit_price * i.quantity)}</span>
                </div>
            `).join("");

            const card = document.createElement("div");
            card.className = "order-card";
            card.innerHTML = `
                <div class="order-card-header">
                    <div>
                        <span class="order-id-badge">${ord.id}</span>
                        <div class="order-date-text">📅 ${dateStr}</div>
                    </div>
                    <span class="order-status-badge status-${ord.status || "pending"}">
                        ${(ord.status || "pending").replace("_", " ")}
                    </span>
                </div>
                <div class="order-items-preview">
                    ${itemsHtml}
                </div>
                <div class="order-card-footer">
                    <span>Direct Farm Delivery: <strong>Paid</strong></span>
                    <span>Total: <strong>₹${ord.total_amount}</strong></span>
                </div>
            `;
            buyerOrdersListContainer.appendChild(card);
        });
    }

    if (openBuyerOrdersBtn) openBuyerOrdersBtn.addEventListener("click", openBuyerOrdersModal);
    if (closeBuyerOrdersModalButton) closeBuyerOrdersModalButton.addEventListener("click", closeBuyerOrdersModal);
    if (buyerOrdersModal) {
        buyerOrdersModal.addEventListener("click", function (e) {
            if (e.target === buyerOrdersModal) closeBuyerOrdersModal();
        });
    }

    /* ====================================================================
       8. BUYER PROFILE MODAL
       ==================================================================== */
    const buyerProfileModal = document.getElementById("buyerProfileModal");
    const closeBuyerProfileModalButton = document.getElementById("closeBuyerProfileModalButton");
    const buyerProfileForm = document.getElementById("buyerProfileForm");
    const profileNameInput = document.getElementById("profileNameInput");
    const profileEmailInput = document.getElementById("profileEmailInput");
    const profilePhoneInput = document.getElementById("profilePhoneInput");
    const profileAddressInput = document.getElementById("profileAddressInput");
    const profileLogoutBtn = document.getElementById("profileLogoutBtn");

    function openBuyerProfileModal() {
        if (!buyerProfileModal) return;
        if (currentUser) {
            if (profileNameInput) profileNameInput.value = currentUser.full_name || "";
            if (profileEmailInput) profileEmailInput.value = currentUser.email || "";
            if (profilePhoneInput) profilePhoneInput.value = currentUser.phone || "";
            if (profileAddressInput) profileAddressInput.value = currentUser.default_address || "";
        }
        buyerProfileModal.style.display = "flex";
    }

    function closeBuyerProfileModal() {
        if (buyerProfileModal) buyerProfileModal.style.display = "none";
    }

    if (openBuyerProfileBtn) openBuyerProfileBtn.addEventListener("click", openBuyerProfileModal);
    if (closeBuyerProfileModalButton) closeBuyerProfileModalButton.addEventListener("click", closeBuyerProfileModal);
    if (buyerProfileModal) {
        buyerProfileModal.addEventListener("click", function (e) {
            if (e.target === buyerProfileModal) closeBuyerProfileModal();
        });
    }

    if (buyerProfileForm) {
        buyerProfileForm.addEventListener("submit", function (e) {
            e.preventDefault();
            if (!currentUser) {
                currentUser = { id: "usr-" + Date.now(), account_type: "consumer" };
            }
            currentUser.full_name = profileNameInput ? profileNameInput.value.trim() : currentUser.full_name;
            currentUser.email = profileEmailInput ? profileEmailInput.value.trim() : currentUser.email;
            currentUser.phone = profilePhoneInput ? profilePhoneInput.value.trim() : currentUser.phone;
            currentUser.default_address = profileAddressInput ? profileAddressInput.value.trim() : "";

            LocalDB.set("currentUser", currentUser);
            updateAuthUI();
            showToast("Profile details updated successfully! 👤");
            closeBuyerProfileModal();
        });
    }

    if (profileLogoutBtn) {
        profileLogoutBtn.addEventListener("click", function () {
            currentUser = null;
            LocalDB.set("currentUser", null);
            updateAuthUI();
            closeBuyerProfileModal();
            showToast("Logged out successfully.");
        });
    }

    /* ====================================================================
       9. CART & CHECKOUT ENGINE
       ==================================================================== */
    let cart = LocalDB.get("cart", []);
    const cartButton = document.getElementById("cartButton");
    const cartCountElement = document.getElementById("cartCount");
    const cartModal = document.getElementById("cartModal");
    const closeCartModalButton = document.getElementById("closeCartModalButton");
    const cartItemsList = document.getElementById("cartItemsList");
    const cartSubtotalText = document.getElementById("cartSubtotalText");
    const cartDeliveryText = document.getElementById("cartDeliveryText");
    const cartGrandTotalText = document.getElementById("cartGrandTotalText");
    const checkoutFormElement = document.getElementById("checkoutFormElement");
    const checkoutBuyerName = document.getElementById("checkoutBuyerName");
    const checkoutBuyerPhone = document.getElementById("checkoutBuyerPhone");
    const checkoutDeliveryAddress = document.getElementById("checkoutDeliveryAddress");

    function updateCartBadge() {
        const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);
        if (cartCountElement) cartCountElement.textContent = totalQty;
        LocalDB.set("cart", cart);
    }

    function addToCart(product) {
        const qtyToAdd = product.quantity || 1;
        const existing = cart.find(item => item.id === product.id);
        if (existing) {
            existing.quantity += qtyToAdd;
        } else {
            cart.push({
                id: product.id,
                name: product.name,
                price: product.price,
                emoji: product.emoji || "🌾",
                unit: product.unit || "kg",
                quantity: qtyToAdd
            });
        }
        updateCartBadge();
        showToast(`Added ${product.name} (${qtyToAdd} ${product.unit || "kg"}) to cart! 🛒`);
    }

    function openCart() {
        if (!cartModal) return;
        renderCartItems();
        if (currentUser) {
            if (checkoutBuyerName) checkoutBuyerName.value = currentUser.full_name || "";
            if (checkoutBuyerPhone) checkoutBuyerPhone.value = currentUser.phone || "";
            if (checkoutDeliveryAddress && currentUser.default_address) {
                checkoutDeliveryAddress.value = currentUser.default_address;
            }
        }
        cartModal.style.display = "flex";
    }

    function closeCart() {
        if (cartModal) cartModal.style.display = "none";
    }

    function renderCartItems() {
        if (!cartItemsList) return;
        cartItemsList.innerHTML = "";

        if (cart.length === 0) {
            cartItemsList.innerHTML = `
                <div class="cart-empty-state" style="text-align:center; padding:30px 10px; color:#778578;">
                    <p style="font-size: 32px; margin-bottom: 6px;">🛒</p>
                    <p><strong>Your cart is empty.</strong></p>
                    <small>Explore the marketplace to add farm-fresh produce!</small>
                </div>
            `;
            if (cartSubtotalText) cartSubtotalText.textContent = "₹0";
            if (cartGrandTotalText) cartGrandTotalText.textContent = "₹0";
            return;
        }

        let subtotal = 0;

        cart.forEach(item => {
            const itemTotal = item.price * item.quantity;
            subtotal += itemTotal;

            const row = document.createElement("div");
            row.className = "cart-item-row";
            row.innerHTML = `
                <div class="cart-item-info">
                    <span class="cart-item-emoji">${item.emoji || "🌾"}</span>
                    <div>
                        <div class="cart-item-name">${item.name}</div>
                        <div class="cart-item-price">₹${item.price}/${item.unit || "kg"}</div>
                    </div>
                </div>
                <div class="cart-qty-ctrls">
                    <button class="qty-btn" data-action="dec" data-id="${item.id}">-</button>
                    <span>${item.quantity} ${item.unit || "kg"}</span>
                    <button class="qty-btn" data-action="inc" data-id="${item.id}">+</button>
                </div>
                <div class="cart-item-total">₹${itemTotal}</div>
            `;
            cartItemsList.appendChild(row);
        });

        const deliveryFee = 40;
        const grandTotal = subtotal + deliveryFee;

        if (cartSubtotalText) cartSubtotalText.textContent = `₹${subtotal}`;
        if (cartDeliveryText) cartDeliveryText.textContent = `₹${deliveryFee}`;
        if (cartGrandTotalText) cartGrandTotalText.textContent = `₹${grandTotal}`;

        // Event listeners for quantity modification
        cartItemsList.querySelectorAll(".qty-btn").forEach(btn => {
            btn.addEventListener("click", function () {
                const id = this.getAttribute("data-id");
                const action = this.getAttribute("data-action");
                const item = cart.find(i => i.id === id);
                if (item) {
                    if (action === "inc") {
                        item.quantity += 1;
                    } else if (action === "dec") {
                        item.quantity -= 1;
                        if (item.quantity <= 0) {
                            cart = cart.filter(i => i.id !== id);
                        }
                    }
                    updateCartBadge();
                    renderCartItems();
                }
            });
        });
    }

    if (cartButton) cartButton.addEventListener("click", openCart);
    if (closeCartModalButton) closeCartModalButton.addEventListener("click", closeCart);
    if (cartModal) {
        cartModal.addEventListener("click", function (e) {
            if (e.target === cartModal) closeCart();
        });
    }

    // Checkout Form Submission -> Supabase Orders Table & LocalDB
    if (checkoutFormElement) {
        checkoutFormElement.addEventListener("submit", async function (e) {
            e.preventDefault();
            if (cart.length === 0) {
                showToast("Your cart is empty!");
                return;
            }

            const buyerName = document.getElementById("checkoutBuyerName").value.trim();
            const buyerPhone = document.getElementById("checkoutBuyerPhone").value.trim();
            const deliveryAddress = document.getElementById("checkoutDeliveryAddress").value.trim();

            const subtotal = cart.reduce((sum, i) => sum + (i.price * i.quantity), 0);
            const totalAmount = subtotal + 40;
            const newOrderId = "ORD-" + Math.floor(1000 + Math.random() * 9000);

            const orderRecord = {
                id: newOrderId,
                buyer_name: buyerName,
                buyer_phone: buyerPhone,
                delivery_address: deliveryAddress,
                total_amount: totalAmount,
                items: cart.map(i => ({ name: i.name, quantity: i.quantity, unit_price: i.price, total: i.price * i.quantity })),
                status: "pending",
                created_at: new Date().toISOString()
            };

            // Deduct stock in products
            const products = LocalDB.get("products", DEFAULT_PRODUCTS);
            cart.forEach(cartItem => {
                const prod = products.find(p => p.id === cartItem.id || p.name === cartItem.name);
                if (prod && prod.stock_qty) {
                    prod.stock_qty = Math.max(0, prod.stock_qty - cartItem.quantity);
                }
            });
            LocalDB.set("products", products);

            // Save in Supabase DB if live
            if (isSupabaseConfigured && supabaseClient) {
                try {
                    await supabaseClient.from("orders").insert([
                        {
                            id: undefined,
                            buyer_name: buyerName,
                            buyer_phone: buyerPhone,
                            delivery_address: deliveryAddress,
                            total_amount: totalAmount,
                            status: "pending"
                        }
                    ]);
                } catch (err) {
                    console.warn("Supabase order insert error, using LocalDB fallback:", err);
                }
            }

            const existingOrders = LocalDB.get("orders", []);
            existingOrders.unshift(orderRecord);
            LocalDB.set("orders", existingOrders);

            // Clear Cart
            cart = [];
            updateCartBadge();
            closeCart();

            showToast(`🎉 Order ${newOrderId} Placed! Direct dispatch scheduled from farm.`);
            renderMarketplaceProducts();
            renderFarmerDashboard();
        });
    }

    /* ====================================================================
       10. FARMER DASHBOARD & PRODUCE MANAGEMENT
       ==================================================================== */
    const farmerDashboardModal = document.getElementById("farmerDashboardModal");
    const closeFarmerModalButton = document.getElementById("closeFarmerModalButton");
    const farmerQuickAddBtn = document.getElementById("farmerQuickAddBtn");
    const tabAddProduceBtn = document.getElementById("tabAddProduceBtn");
    const tabMyListingsBtn = document.getElementById("tabMyListingsBtn");
    const tabFarmerOrdersBtn = document.getElementById("tabFarmerOrdersBtn");
    const addProduceSection = document.getElementById("addProduceSection");
    const myListingsSection = document.getElementById("myListingsSection");
    const farmerOrdersSection = document.getElementById("farmerOrdersSection");
    const farmerAddCropForm = document.getElementById("farmerAddCropForm");
    const farmerListingsTableBody = document.getElementById("farmerListingsTableBody");
    const farmerOrdersTableBody = document.getElementById("farmerOrdersTableBody");
    const myListingsCount = document.getElementById("myListingsCount");
    const farmerOrdersCount = document.getElementById("farmerOrdersCount");

    function openFarmerDashboard() {
        if (!farmerDashboardModal) return;
        renderFarmerDashboard();
        farmerDashboardModal.style.display = "flex";
    }

    function closeFarmerDashboard() {
        if (farmerDashboardModal) farmerDashboardModal.style.display = "none";
    }

    function switchFarmerTab(targetTabId) {
        [tabAddProduceBtn, tabMyListingsBtn, tabFarmerOrdersBtn].forEach(btn => {
            if (btn) btn.classList.remove("active");
        });
        [addProduceSection, myListingsSection, farmerOrdersSection].forEach(sec => {
            if (sec) sec.classList.add("hidden");
        });

        if (targetTabId === "addProduceSection") {
            if (tabAddProduceBtn) tabAddProduceBtn.classList.add("active");
            if (addProduceSection) addProduceSection.classList.remove("hidden");
        } else if (targetTabId === "myListingsSection") {
            if (tabMyListingsBtn) tabMyListingsBtn.classList.add("active");
            if (myListingsSection) myListingsSection.classList.remove("hidden");
        } else if (targetTabId === "farmerOrdersSection") {
            if (tabFarmerOrdersBtn) tabFarmerOrdersBtn.classList.add("active");
            if (farmerOrdersSection) farmerOrdersSection.classList.remove("hidden");
        }
    }

    if (tabAddProduceBtn) tabAddProduceBtn.addEventListener("click", () => switchFarmerTab("addProduceSection"));
    if (tabMyListingsBtn) tabMyListingsBtn.addEventListener("click", () => switchFarmerTab("myListingsSection"));
    if (tabFarmerOrdersBtn) tabFarmerOrdersBtn.addEventListener("click", () => switchFarmerTab("farmerOrdersSection"));
    if (closeFarmerModalButton) closeFarmerModalButton.addEventListener("click", closeFarmerDashboard);
    if (openFarmerDashboardBtn) openFarmerDashboardBtn.addEventListener("click", openFarmerDashboard);
    if (farmerQuickAddBtn) farmerQuickAddBtn.addEventListener("click", openFarmerDashboard);

    if (farmerDashboardModal) {
        farmerDashboardModal.addEventListener("click", function (e) {
            if (e.target === farmerDashboardModal) closeFarmerDashboard();
        });
    }

    function renderFarmerDashboard() {
        const products = LocalDB.get("products", DEFAULT_PRODUCTS);
        const orders = LocalDB.get("orders", []);

        if (myListingsCount) myListingsCount.textContent = products.length;
        if (farmerOrdersCount) farmerOrdersCount.textContent = orders.length;

        // Render My Listings Table
        if (farmerListingsTableBody) {
            farmerListingsTableBody.innerHTML = "";
            products.forEach(p => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td><strong>${p.image_emoji || "🌾"} ${p.name}</strong></td>
                    <td>${p.category}</td>
                    <td>₹${p.price_per_kg}/${p.unit || "kg"}</td>
                    <td>${p.stock_qty || 100} ${p.unit || "kg"}</td>
                    <td>${p.location || "Farm Gate"}</td>
                    <td><span class="table-badge badge-instock">Active</span></td>
                    <td>
                        <button class="table-btn delete-btn" data-del-id="${p.id}">Delete</button>
                    </td>
                `;
                farmerListingsTableBody.appendChild(tr);
            });

            farmerListingsTableBody.querySelectorAll(".delete-btn").forEach(btn => {
                btn.addEventListener("click", function () {
                    const id = this.getAttribute("data-del-id");
                    const updated = products.filter(p => p.id !== id);
                    LocalDB.set("products", updated);
                    renderFarmerDashboard();
                    renderMarketplaceProducts();
                    showToast("Listing removed.");
                });
            });
        }

        // Render Orders Table
        if (farmerOrdersTableBody) {
            farmerOrdersTableBody.innerHTML = "";
            orders.forEach(ord => {
                const tr = document.createElement("tr");
                const itemsSummary = (ord.items || []).map(i => `${i.name} (${i.quantity}kg)`).join(", ");
                tr.innerHTML = `
                    <td><strong>${ord.id}</strong></td>
                    <td>${ord.buyer_name}<br><small>${ord.buyer_phone}</small></td>
                    <td><small>${itemsSummary}</small></td>
                    <td><strong>₹${ord.total_amount}</strong></td>
                    <td>
                        <span class="table-badge badge-${ord.status}">${ord.status.toUpperCase()}</span>
                    </td>
                    <td>
                        <select class="order-status-select" data-order-id="${ord.id}" style="padding: 4px; font-size: 11px; border-radius: 6px; border: 1px solid #d5dfd3;">
                            <option value="pending" ${ord.status === "pending" ? "selected" : ""}>Pending</option>
                            <option value="packed" ${ord.status === "packed" ? "selected" : ""}>Packed</option>
                            <option value="in_transit" ${ord.status === "in_transit" ? "selected" : ""}>In Transit</option>
                            <option value="delivered" ${ord.status === "delivered" ? "selected" : ""}>Delivered</option>
                        </select>
                    </td>
                `;
                farmerOrdersTableBody.appendChild(tr);
            });

            farmerOrdersTableBody.querySelectorAll(".order-status-select").forEach(sel => {
                sel.addEventListener("change", function () {
                    const ordId = this.getAttribute("data-order-id");
                    const newStatus = this.value;
                    const allOrders = LocalDB.get("orders", []);
                    const target = allOrders.find(o => o.id === ordId);
                    if (target) {
                        target.status = newStatus;
                        LocalDB.set("orders", allOrders);
                        showToast(`Order ${ordId} status updated to: ${newStatus}`);
                        renderFarmerDashboard();
                    }
                });
            });
        }
    }

    // Farmer Add Produce Form Submission
    if (farmerAddCropForm) {
        farmerAddCropForm.addEventListener("submit", async function (e) {
            e.preventDefault();
            const name = document.getElementById("cropNameInput").value.trim();
            const category = document.getElementById("cropCategorySelect").value;
            const price = parseFloat(document.getElementById("cropPriceInput").value);
            const stock = parseFloat(document.getElementById("cropStockInput").value);
            const unit = document.getElementById("cropUnitSelect").value;
            const location = document.getElementById("cropLocationInput").value.trim();
            const emoji = document.getElementById("cropEmojiSelect").value;
            const desc = document.getElementById("cropDescInput").value.trim();

            const newProduct = {
                id: "prod-" + Date.now(),
                farmer_name: currentUser ? (currentUser.full_name + " (Verified Farmer)") : "Local Verified Farmer",
                name,
                category,
                price_per_kg: price,
                stock_qty: stock,
                unit,
                location,
                image_emoji: emoji,
                is_verified: true,
                description: desc || "Freshly harvested produce direct from farm gate."
            };

            // Save to Supabase if configured
            if (isSupabaseConfigured && supabaseClient) {
                try {
                    await supabaseClient.from("products").insert([
                        {
                            name,
                            category,
                            price_per_kg: price,
                            stock_qty: stock,
                            unit,
                            location,
                            image_emoji: emoji,
                            description: desc,
                            is_verified: true
                        }
                    ]);
                } catch (err) {
                    console.warn("Supabase product insert fallback:", err);
                }
            }

            const products = LocalDB.get("products", DEFAULT_PRODUCTS);
            products.unshift(newProduct);
            LocalDB.set("products", products);

            farmerAddCropForm.reset();
            renderFarmerDashboard();
            renderMarketplaceProducts();
            switchFarmerTab("myListingsSection");
            showToast(`🌾 ${name} successfully listed on KhetKonnect Marketplace!`);
        });
    }

    /* ====================================================================
       11. SMART ROUTE & LOGISTICS NAVIGATION ENGINE (LEAFLET MAP)
       ==================================================================== */
    const routeModal = document.getElementById("routeModal");
    const logisticsButton = document.getElementById("logisticsButton");
    const closeRouteModalButton = document.getElementById("closeRouteModalButton");
    const heroDeliveryCard = document.getElementById("heroDeliveryCard");
    const openRouteModalFromCard = document.getElementById("openRouteModalFromCard");
    const calculateRouteBtn = document.getElementById("calculateRouteBtn");
    const dispatchRouteBtn = document.getElementById("dispatchRouteBtn");
    const useCurrentLocationOriginBtn = document.getElementById("useCurrentLocationOriginBtn");
    const useCurrentLocationDestBtn = document.getElementById("useCurrentLocationDestBtn");
    const routeOriginInput = document.getElementById("routeOriginInput");
    const routeDestInput = document.getElementById("routeDestInput");
    const routeVehicleSelect = document.getElementById("routeVehicleSelect");
    const metricDistanceVal = document.getElementById("metricDistanceVal");
    const metricTimeVal = document.getElementById("metricTimeVal");
    const metricCostVal = document.getElementById("metricCostVal");
    const metricCo2Val = document.getElementById("metricCo2Val");
    const trackingStatusText = document.getElementById("trackingStatusText");
    const trackingPickupText = document.getElementById("trackingPickupText");
    const trackingDestText = document.getElementById("trackingDestText");
    const trackingEtaText = document.getElementById("trackingEtaText");

    let leafletMapInstance = null;
    let originMarker = null;
    let destMarker = null;
    let routePolyline = null;

    const KNOWN_COORDINATES = {
        "nashik": [19.9975, 73.7898],
        "mumbai": [19.0760, 72.8777],
        "vashi": [19.0771, 72.9986],
        "sambalpur": [21.4669, 83.9812],
        "bhubaneswar": [20.2961, 85.8245],
        "kolar": [13.1362, 78.1291],
        "bengaluru": [12.9716, 77.5946],
        "bangalore": [12.9716, 77.5946],
        "ludhiana": [30.9010, 75.8573],
        "delhi": [28.7041, 77.1025],
        "agra": [27.1767, 78.0081],
        "pune": [18.5204, 73.8567],
        "hyderabad": [17.3850, 78.4867],
        "chennai": [13.0827, 80.2707],
        "kolkata": [22.5726, 88.3639]
    };

    function geocodeLocation(query) {
        const lower = query.toLowerCase();
        for (const [key, coords] of Object.entries(KNOWN_COORDINATES)) {
            if (lower.includes(key)) {
                return coords;
            }
        }
        return [19.8 + (Math.random() * 1.5), 74.5 + (Math.random() * 2.0)];
    }

    function initLogisticsMap() {
        if (!window.L) return;
        const mapContainer = document.getElementById("logisticsMap");
        if (!mapContainer) return;

        if (leafletMapInstance) {
            leafletMapInstance.invalidateSize();
            return;
        }

        try {
            leafletMapInstance = L.map("logisticsMap").setView([19.5, 73.5], 8);

            L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: "© OpenStreetMap contributors"
            }).addTo(leafletMapInstance);

            calculateAndDrawRoute();
        } catch (e) {
            console.warn("Leaflet map initialization warning:", e);
        }
    }

    function calculateAndDrawRoute() {
        if (!leafletMapInstance || !window.L) return;

        const originText = routeOriginInput ? routeOriginInput.value : "Nashik, Maharashtra";
        const destText = routeDestInput ? routeDestInput.value : "Mumbai APMC Mandi";
        const vehicleType = routeVehicleSelect ? routeVehicleSelect.value : "mini_truck";

        const originCoords = geocodeLocation(originText);
        const destCoords = geocodeLocation(destText);

        if (originMarker) leafletMapInstance.removeLayer(originMarker);
        if (destMarker) leafletMapInstance.removeLayer(destMarker);
        if (routePolyline) leafletMapInstance.removeLayer(routePolyline);

        const farmIcon = L.divIcon({
            className: "custom-map-pin",
            html: `<div style="background-color:#2f913f; color:white; border-radius:50%; width:34px; height:34px; display:flex; align-items:center; justify-content:center; font-size:18px; box-shadow:0 3px 10px rgba(0,0,0,0.3); border:2px solid white;">🚜</div>`,
            iconSize: [34, 34],
            iconAnchor: [17, 34]
        });

        const destIcon = L.divIcon({
            className: "custom-map-pin",
            html: `<div style="background-color:#c53030; color:white; border-radius:50%; width:34px; height:34px; display:flex; align-items:center; justify-content:center; font-size:18px; box-shadow:0 3px 10px rgba(0,0,0,0.3); border:2px solid white;">🛒</div>`,
            iconSize: [34, 34],
            iconAnchor: [17, 34]
        });

        originMarker = L.marker(originCoords, { icon: farmIcon })
            .addTo(leafletMapInstance)
            .bindPopup(`<b>🚜 Pickup Origin:</b><br>${originText}`)
            .openPopup();

        destMarker = L.marker(destCoords, { icon: destIcon })
            .addTo(leafletMapInstance)
            .bindPopup(`<b>🛒 Delivery Destination:</b><br>${destText}`);

        const midLat = (originCoords[0] + destCoords[0]) / 2 + 0.05;
        const midLng = (originCoords[1] + destCoords[1]) / 2 - 0.05;
        const routePoints = [originCoords, [midLat, midLng], destCoords];

        routePolyline = L.polyline(routePoints, {
            color: "#2f913f",
            weight: 5,
            dashArray: "8, 8",
            lineCap: "round"
        }).addTo(leafletMapInstance);

        leafletMapInstance.fitBounds(L.latLngBounds([originCoords, destCoords]), { padding: [40, 40] });

        const dLat = (destCoords[0] - originCoords[0]) * 111;
        const dLng = (destCoords[1] - originCoords[1]) * 105;
        const straightDist = Math.sqrt(dLat * dLat + dLng * dLng);
        const roadDist = Math.max(25, Math.round(straightDist * 1.28 * 10) / 10);

        let speedKmH = 45;
        let baseRatePerKm = 16;
        let co2Saving = "-18.5%";

        if (vehicleType === "refrigerated") {
            baseRatePerKm = 24;
            speedKmH = 50;
            co2Saving = "-22.0% (Eco Cold Chain)";
        } else if (vehicleType === "heavy_truck") {
            baseRatePerKm = 35;
            speedKmH = 40;
            co2Saving = "-14.2%";
        } else if (vehicleType === "e_rickshaw") {
            baseRatePerKm = 10;
            speedKmH = 25;
            co2Saving = "-100% (Zero Emission)";
        }

        const totalHours = roadDist / speedKmH;
        const hours = Math.floor(totalHours);
        const mins = Math.round((totalHours - hours) * 60);
        const timeStr = hours > 0 ? `${hours} hr ${mins} mins` : `${mins} mins`;
        const freightCost = Math.round(roadDist * baseRatePerKm + 450);

        if (metricDistanceVal) metricDistanceVal.textContent = `${roadDist} km`;
        if (metricTimeVal) metricTimeVal.textContent = timeStr;
        if (metricCostVal) metricCostVal.textContent = `₹${freightCost.toLocaleString("en-IN")}`;
        if (metricCo2Val) metricCo2Val.textContent = co2Saving;

        if (trackingPickupText) trackingPickupText.textContent = originText;
        if (trackingDestText) trackingDestText.textContent = destText;
        if (trackingEtaText) trackingEtaText.textContent = `Today • ${timeStr} (${roadDist} km)`;
        if (trackingStatusText) trackingStatusText.textContent = "Route Ready / Optimized";
    }

    function openRouteModal() {
        if (!routeModal) return;
        routeModal.style.display = "flex";
        setTimeout(initLogisticsMap, 200);
    }

    function closeRouteModal() {
        if (routeModal) routeModal.style.display = "none";
    }

    if (logisticsButton) logisticsButton.addEventListener("click", openRouteModal);
    if (heroDeliveryCard) heroDeliveryCard.addEventListener("click", openRouteModal);
    if (openRouteModalFromCard) openRouteModalFromCard.addEventListener("click", openRouteModal);
    if (closeRouteModalButton) closeRouteModalButton.addEventListener("click", closeRouteModal);
    if (calculateRouteBtn) calculateRouteBtn.addEventListener("click", calculateAndDrawRoute);

    if (routeModal) {
        routeModal.addEventListener("click", function (e) {
            if (e.target === routeModal) closeRouteModal();
        });
    }

    document.querySelectorAll(".corridor-chip").forEach(chip => {
        chip.addEventListener("click", function () {
            const orig = this.getAttribute("data-orig");
            const dest = this.getAttribute("data-dest");
            if (routeOriginInput) routeOriginInput.value = orig;
            if (routeDestInput) routeDestInput.value = dest;
            calculateAndDrawRoute();
        });
    });

    function handleGPS(inputElement) {
        if (!navigator.geolocation) {
            showToast("Geolocation is not supported by your browser.");
            return;
        }
        showToast("Fetching current GPS location... 📍");
        navigator.geolocation.getCurrentPosition(
            pos => {
                const lat = pos.coords.latitude.toFixed(4);
                const lng = pos.coords.longitude.toFixed(4);
                if (inputElement) inputElement.value = `Current Location (${lat}, ${lng})`;
                showToast(`Location set: ${lat}, ${lng}`);
                calculateAndDrawRoute();
            },
            err => {
                showToast("Could not access GPS. Using cluster coordinates.");
                if (inputElement) inputElement.value = "Current Farm Location (19.9975, 73.7898)";
                calculateAndDrawRoute();
            }
        );
    }

    if (useCurrentLocationOriginBtn) {
        useCurrentLocationOriginBtn.addEventListener("click", () => handleGPS(routeOriginInput));
    }
    if (useCurrentLocationDestBtn) {
        useCurrentLocationDestBtn.addEventListener("click", () => handleGPS(routeDestInput));
    }

    if (dispatchRouteBtn) {
        dispatchRouteBtn.addEventListener("click", async function () {
            const origin = routeOriginInput ? routeOriginInput.value : "Farm";
            const dest = routeDestInput ? routeDestInput.value : "Market";
            const distance = metricDistanceVal ? metricDistanceVal.textContent : "168 km";
            const cost = metricCostVal ? metricCostVal.textContent : "₹2,850";
            const waybillNo = "WB-" + Math.floor(100000 + Math.random() * 900000);

            if (isSupabaseConfigured && supabaseClient) {
                try {
                    await supabaseClient.from("logistics_routes").insert([
                        {
                            origin_name: origin,
                            dest_name: dest,
                            distance_km: parseFloat(distance) || 168,
                            eta_minutes: 220,
                            estimated_cost: parseFloat(cost.replace(/[^\d.]/g, "")) || 2850,
                            status: "scheduled"
                        }
                    ]);
                } catch (e) {
                    console.warn("Supabase route save error:", e);
                }
            }

            if (trackingStatusText) trackingStatusText.textContent = `Dispatched (${waybillNo})`;
            showToast(`📦 Waybill ${waybillNo} Created! Dispatch allocated for ${origin} ➔ ${dest}.`);
            closeRouteModal();
        });
    }

    /* ====================================================================
       12. VOICE ASSISTANT & SPEECH RECOGNITION / SYNTHESIS
       ==================================================================== */
    const voiceAssistantButton = document.getElementById("voiceAssistantButton");
    const voiceModal = document.getElementById("voiceModal");
    const closeVoiceModalButton = document.getElementById("closeVoiceModalButton");
    const stopVoiceListeningBtn = document.getElementById("stopVoiceListeningBtn");
    const voiceStatusHeading = document.getElementById("voiceStatusHeading");
    const voiceTranscriptDisplay = document.getElementById("voiceTranscriptDisplay");

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    let recognitionInstance = null;

    function speakText(text, langCode) {
        if (!("speechSynthesis" in window)) return;
        window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;

        const langVoiceMap = {
            en: "en-IN",
            hi: "hi-IN",
            or: "or-IN",
            pa: "pa-IN",
            mr: "mr-IN",
            bn: "bn-IN",
            te: "te-IN",
            ta: "ta-IN"
        };
        utterance.lang = langVoiceMap[langCode || currentLanguage] || "en-IN";

        window.speechSynthesis.speak(utterance);
    }

    function initSpeechRecognition() {
        if (!SpeechRecognition) {
            console.warn("Web Speech Recognition not supported in this browser.");
            return null;
        }

        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;

        const langRecogMap = {
            en: "en-IN",
            hi: "hi-IN",
            or: "or-IN",
            pa: "pa-IN",
            mr: "mr-IN",
            bn: "bn-IN",
            te: "te-IN",
            ta: "ta-IN"
        };
        recognition.lang = langRecogMap[currentLanguage] || "en-IN";

        recognition.onstart = function () {
            if (voiceAssistantButton) voiceAssistantButton.classList.add("listening");
            if (voiceStatusHeading) voiceStatusHeading.textContent = "Listening... Speak now 🎙️";
        };

        recognition.onresult = function (event) {
            let interimTranscript = "";
            let finalTranscript = "";

            for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) {
                    finalTranscript += event.results[i][0].transcript;
                } else {
                    interimTranscript += event.results[i][0].transcript;
                }
            }

            const currentSpeech = finalTranscript || interimTranscript;
            if (voiceTranscriptDisplay) {
                voiceTranscriptDisplay.textContent = `"${currentSpeech}"`;
            }

            if (finalTranscript) {
                handleVoiceCommand(finalTranscript.toLowerCase());
            }
        };

        recognition.onerror = function (event) {
            console.warn("Voice recognition error:", event.error);
            if (voiceStatusHeading) voiceStatusHeading.textContent = "Tap a suggested command below or try speaking again:";
        };

        recognition.onend = function () {
            if (voiceAssistantButton) voiceAssistantButton.classList.remove("listening");
        };

        return recognition;
    }

    function handleVoiceCommand(cmd) {
        cmd = cmd.toLowerCase().trim();
        console.log("🎙️ Voice command received:", cmd);

        if (cmd.includes("veg") || cmd.includes("सब्जी") || cmd.includes("तରକାରୀ") || cmd.includes("શાક")) {
            currentCategoryFilter = "vegetables";
            filterButtons.forEach(b => {
                if (b.getAttribute("data-category") === "vegetables") b.classList.add("active");
                else b.classList.remove("active");
            });
            renderMarketplaceProducts();
            speakText("Showing fresh vegetables from local farmers.", currentLanguage);
            showToast("Filtering: Vegetables 🍅");
            document.getElementById("marketplace")?.scrollIntoView({ behavior: "smooth" });
            closeVoiceModal();
        } else if (cmd.includes("fruit") || cmd.includes("फल") || cmd.includes("ଫଳ") || cmd.includes("ফল")) {
            currentCategoryFilter = "fruits";
            filterButtons.forEach(b => {
                if (b.getAttribute("data-category") === "fruits") b.classList.add("active");
                else b.classList.remove("active");
            });
            renderMarketplaceProducts();
            speakText("Showing fresh fruits.", currentLanguage);
            showToast("Filtering: Fruits 🍎");
            document.getElementById("marketplace")?.scrollIntoView({ behavior: "smooth" });
            closeVoiceModal();
        } else if (cmd.includes("grain") || cmd.includes("rice") || cmd.includes("wheat") || cmd.includes("अनाज") || cmd.includes("ଶସ୍ୟ")) {
            currentCategoryFilter = "grains";
            filterButtons.forEach(b => {
                if (b.getAttribute("data-category") === "grains") b.classList.add("active");
                else b.classList.remove("active");
            });
            renderMarketplaceProducts();
            speakText("Showing grains and pulses.", currentLanguage);
            showToast("Filtering: Grains 🌾");
            document.getElementById("marketplace")?.scrollIntoView({ behavior: "smooth" });
            closeVoiceModal();
        } else if (cmd.includes("favorite") || cmd.includes("पसंदीदा") || cmd.includes("fav")) {
            closeVoiceModal();
            openFavoritesModal();
            speakText("Opening your saved favorites.", currentLanguage);
        } else if (cmd.includes("order") || cmd.includes("ऑर्डर") || cmd.includes("ଅର୍ଡର")) {
            closeVoiceModal();
            openBuyerOrdersModal();
            speakText("Opening your order history.", currentLanguage);
        } else if (cmd.includes("all") || cmd.includes("सब") || cmd.includes("ਸਾਰੇ")) {
            currentCategoryFilter = "all";
            currentSearchQuery = "";
            if (produceSearchInput) produceSearchInput.value = "";
            filterButtons.forEach(b => {
                if (b.getAttribute("data-category") === "all") b.classList.add("active");
                else b.classList.remove("active");
            });
            renderMarketplaceProducts();
            speakText("Showing all fresh farm produce.", currentLanguage);
            closeVoiceModal();
        } else if (cmd.includes("cart") || cmd.includes("टोकरी") || cmd.includes("basket") || cmd.includes("କାର୍ଟ")) {
            closeVoiceModal();
            openCart();
            speakText("Opening your farm direct cart.", currentLanguage);
        } else if (cmd.includes("route") || cmd.includes("logistics") || cmd.includes("map") || cmd.includes("रास्ता") || cmd.includes("नक्शा") || cmd.includes("ଗାଡ଼ି")) {
            closeVoiceModal();
            openRouteModal();
            speakText("Opening smart route and logistics planner.", currentLanguage);
        } else if (cmd.includes("farmer") || cmd.includes("crop") || cmd.includes("किसान") || cmd.includes("ਫ਼ਸਲ") || cmd.includes("ଚାଷୀ")) {
            closeVoiceModal();
            openFarmerDashboard();
            speakText("Opening farmer produce management center.", currentLanguage);
        } else if (cmd.includes("login") || cmd.includes("लॉगिन") || cmd.includes("साइन इन")) {
            closeVoiceModal();
            openLogin();
            speakText("Opening login window.", currentLanguage);
        } else if (cmd.includes("hindi") || cmd.includes("हिन्दी")) {
            setLanguage("hi");
            speakText("भाषा बदलकर हिन्दी कर दी गई है।", "hi");
            closeVoiceModal();
        } else if (cmd.includes("english") || cmd.includes("अंग्रेजी")) {
            setLanguage("en");
            speakText("Language switched to English.", "en");
            closeVoiceModal();
        } else if (cmd.includes("odia") || cmd.includes("ଓଡ଼ିଆ")) {
            setLanguage("or");
            speakText("ଭାଷା ଓଡ଼ିଆ କରାଗଲା।", "or");
            closeVoiceModal();
        } else {
            // Search produce by spoken keyword
            if (produceSearchInput) {
                produceSearchInput.value = cmd;
                currentSearchQuery = cmd;
                if (clearSearchBtn) clearSearchBtn.style.display = "block";
                renderMarketplaceProducts();
                document.getElementById("marketplace")?.scrollIntoView({ behavior: "smooth" });
            }
            speakText(`Searching for ${cmd}`, currentLanguage);
            showToast(`Searched: "${cmd}" 🔍`);
            closeVoiceModal();
        }
    }

    function startVoiceListening() {
        if (!voiceModal) return;
        voiceModal.style.display = "flex";

        if (!recognitionInstance) {
            recognitionInstance = initSpeechRecognition();
        }

        if (recognitionInstance) {
            try {
                recognitionInstance.start();
            } catch (e) {
                console.warn("Speech recognition restart triggered");
            }
        }
    }

    function closeVoiceModal() {
        if (voiceModal) voiceModal.style.display = "none";
        if (recognitionInstance) {
            try { recognitionInstance.stop(); } catch (e) {}
        }
        if (voiceAssistantButton) voiceAssistantButton.classList.remove("listening");
    }

    if (voiceAssistantButton) voiceAssistantButton.addEventListener("click", startVoiceListening);
    if (closeVoiceModalButton) closeVoiceModalButton.addEventListener("click", closeVoiceModal);
    if (stopVoiceListeningBtn) stopVoiceListeningBtn.addEventListener("click", closeVoiceModal);

    document.querySelectorAll(".voice-helper-chips .chip").forEach(chip => {
        chip.addEventListener("click", function () {
            const text = this.getAttribute("data-speak");
            if (voiceTranscriptDisplay) voiceTranscriptDisplay.textContent = `"${text}"`;
            handleVoiceCommand(text);
        });
    });

    /* ====================================================================
       13. AI DEMAND FORECASTING & CROP RECOMMENDATIONS
       ==================================================================== */
    const cropChips = document.querySelectorAll(".crop-chip");
    const aiForecastValue = document.getElementById("aiForecastValue");
    const aiSelectedCropHeader = document.getElementById("aiSelectedCropHeader");
    const aiRecommendationText = document.getElementById("aiRecommendationText");
    const aiForecastChart = document.getElementById("aiForecastChart");

    const AI_CROP_FORECAST_DATA = {
        "Tomatoes": {
            spike: "+24.8%",
            bars: ["40%", "55%", "45%", "70%", "65%", "90%"],
            advice: "Optimal harvest time: Next 48 hours. High wholesale tomato demand expected in nearby urban clusters due to festival season."
        },
        "Potatoes": {
            spike: "+18.2%",
            bars: ["50%", "60%", "65%", "55%", "75%", "82%"],
            advice: "Cold storage release recommended. Stable market price expected with 15% margin improvement in direct sales."
        },
        "Apples": {
            spike: "+36.5%",
            bars: ["30%", "45%", "60%", "80%", "85%", "95%"],
            advice: "Premium grade Royal Delicious high demand. Bulk purchase orders rising from metro retail cooperatives."
        },
        "Rice": {
            spike: "+15.0%",
            bars: ["60%", "65%", "70%", "68%", "72%", "78%"],
            advice: "Long-grain aromatic rice steady consumption. High bulk demand from institutional kitchens and FPO buyers."
        },
        "Onions": {
            spike: "+29.4%",
            bars: ["45%", "50%", "70%", "85%", "90%", "92%"],
            advice: "Export demand surge detected. Well-cured red onions fetching 20% higher farmer price this week."
        }
    };

    cropChips.forEach(chip => {
        chip.addEventListener("click", function () {
            cropChips.forEach(c => c.classList.remove("active"));
            this.classList.add("active");

            const crop = this.getAttribute("data-crop");
            const data = AI_CROP_FORECAST_DATA[crop];
            if (!data) return;

            if (aiForecastValue) aiForecastValue.textContent = data.spike;
            if (aiSelectedCropHeader) aiSelectedCropHeader.textContent = `Demand Forecast (${crop})`;
            if (aiRecommendationText) aiRecommendationText.textContent = data.advice;

            if (aiForecastChart) {
                const bars = aiForecastChart.querySelectorAll(".bar");
                bars.forEach((bar, index) => {
                    if (data.bars[index]) {
                        bar.style.height = data.bars[index];
                        bar.setAttribute("title", `Day ${index + 1}: ${data.bars[index]}`);
                    }
                });
            }
        });
    });

    /* ====================================================================
       14. MOBILE MENU & TOAST NOTIFICATION UTILITIES
       ==================================================================== */
    const toast = document.getElementById("toast");
    const menuButton = document.getElementById("menuButton");
    const navMenu = document.getElementById("navMenu");

    function showToast(message) {
        if (!toast) return;
        toast.textContent = message;
        toast.style.display = "block";

        clearTimeout(toast._timeout);
        toast._timeout = setTimeout(function () {
            toast.style.display = "none";
        }, 3200);
    }

    if (menuButton && navMenu) {
        menuButton.addEventListener("click", function () {
            if (navMenu.style.display === "flex") {
                navMenu.style.display = "none";
            } else {
                navMenu.style.display = "flex";
                navMenu.style.position = "absolute";
                navMenu.style.top = "75px";
                navMenu.style.left = "0";
                navMenu.style.width = "100%";
                navMenu.style.flexDirection = "column";
                navMenu.style.backgroundColor = "#ffffff";
                navMenu.style.padding = "20px";
                navMenu.style.zIndex = "999";
                navMenu.style.boxShadow = "0 10px 25px rgba(0,0,0,0.1)";
            }
        });
    }

    document.querySelectorAll("#navMenu a").forEach(link => {
        link.addEventListener("click", function () {
            if (window.innerWidth <= 1000 && navMenu) {
                navMenu.style.display = "none";
            }
        });
    });

    // Close modals on Escape key
    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") {
            closeAuth();
            closeCart();
            closeRouteModal();
            closeFarmerDashboard();
            closeVoiceModal();
            closeProductDetails();
            closeFavoritesModal();
            closeBuyerOrdersModal();
            closeBuyerProfileModal();
        }
    });

    /* ====================================================================
       INITIALIZATION CALLS
       ==================================================================== */
    setLanguage(currentLanguage);
    updateAuthUI();
    updateCartBadge();
    updateFavoritesBadge();
    renderMarketplaceProducts();
    renderFarmerDashboard();

    console.log("🌾 KhetKonnect Full-Stack Platform Initialized Successfully!");
});
